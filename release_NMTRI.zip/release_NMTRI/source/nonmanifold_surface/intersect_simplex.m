function intersect_flag = intersect_simplex ( tau, L, U )
% function intersect_flag = intersect_simplex ( tau, L, U )
% This function returns true if the simplex tau intersects
% the current complex L in such a way that adding it to the complex
% would violate the conditions of a simplicial complex.
%
% INPUTS: tau -- simplex
%         L -- subcomplex in neighborhood Gamma
%         U -- projection of points in X(:,Gamma) onto tangent plane
%              (note U(:,~Gamma) are NaNs)
%
% OUTPUT: intersect_flag -- true if there is an illegal intersection
%                           of new coface f2 with existing complex
%
% NOTE:
% 1.  This routine assumes that tau is not a subset of any sigma in L.
% 2.  This routine works by solving a linear program to check
%     if there are intersecting complexes.  You therefore need to
%     have the optimization toolbox linprog.m file.
%
% S. Martin
% 9/24/2008

% linear program machine tolerance pseudo-constant
lin_eps = 10^-8;

% innocent until proven guilty
intersect_flag = false;

% look through neighborhood subcomplex to find violations
for i = 1:length(L)
    for j = 1:size(L{i},2)
        
        % get a simplex in L
        sigma = L{i}(:,j);
        
        % define coefficients of function to minimize in LP
        f = -[~ismember(tau,sigma);zeros(size(sigma))];
        
        % define equalities
        Aeq = [U(:,tau),-U(:,sigma);ones(size(tau))',zeros(size(sigma))';...
            zeros(size(tau))',ones(size(sigma))'];
        beq = [zeros(size(U,1),1);1;1];
        
        % define lower bounds
        lb = [zeros(size(tau));zeros(size(sigma))];
        
        % solve linear program (using linprog)
        options = optimset ('LargeScale', 'off', 'Simplex', 'on', ...
            'Display', 'off');
        [x,fval,exitflag] = linprog ( f, [], [], Aeq, beq, lb, ...
            [], [], options );

        % solve linear program (using qsopt)
        %[x,fval,exitflag] = qsopt ( f, [], [], Aeq, beq, lb );        
        %fval = f'*x;
        
        % if feasible solution with objective > 0 then 
        % intersection is illegal & we can stop
        if (exitflag == 1) && (fval < -lin_eps)
            intersect_flag = true;
            return
        end
        
    end
end