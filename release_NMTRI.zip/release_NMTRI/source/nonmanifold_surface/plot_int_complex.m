function plot_int_complex ( X, K, ints )
% function plot_int_complex ( X, K, ints )
% Plots the a complex with intersections as black lines.
%
% INPUTS: X -- coordinates, point as columns
%         K -- complex, as returned by triangulate_surface
%              (note that these are the only points plotted)
%         ints -- indices of intersection
%
% OUTPUT: plot of complex with intersections.
%
% S. Martin
% 1/22/2009

% NOTE: This is actually part of a more general code which can
% plot three components in different colors

% set background to white
h = gcf;
set(h,'Color',[1 1 1]);

% first plot vertices
color_verts = 0;
if ~color_verts
    % plot all grey vertices
    plot3 ( X(1,K{1}), X(2,K{1}), X(3,K{1}), '.', 'Color', [.9 .9 .9] );
    hold on
else
    plot3 ( X(1,intersect (K{1},find(comp==1))), ...
        X(2,intersect (K{1},find(comp==1))), ...
        X(3,intersect (K{1},find(comp==1))), 'bo');
    hold on
    plot3 ( X(1,intersect (K{1},find(comp==3))), ...
        X(2,intersect (K{1},find(comp==3))), ...
        X(3,intersect (K{1},find(comp==3))), 'go');
    plot3 ( X(1,intersect (K{1},find(comp==2))), ...
        X(2,intersect (K{1},find(comp==2))), ...
        X(3,intersect (K{1},find(comp==2))), 'ro');
end

% set components so that 1 = non-intersections,
% 2 = intersections
comp = ones(1,size(X,2));
comp(ints) = 2;

% set face transparency
face_weights = [.25,0];

% next plot lines
edges = K{2};
n_edges = size(edges,2);
color_coding = [ .9 .9 .9; 0 0 0; .9 .9 .9];
edge_widths = [.5 3 .5];
for i = 1:n_edges
   edge_colors = sort(comp(edges(:,i)));
   if edge_colors(1)==edge_colors(2)   % same color edge
       edge_color = color_coding(edge_colors(1),:);
       edge_width = edge_widths(edge_colors(1));
   elseif (edge_colors(1)==1) && ...     % r-b edge
          (edge_colors(2)==2)
       edge_color = color_coding(1,:);
       edge_width = edge_widths(1);
   elseif (edge_colors(1)==2) && ...     % r-g edge
          (edge_colors(2)==3)
       edge_color = color_coding(3,:);
       edge_width = edge_widths(3);
   else
       fprintf('warning: b-g edge detected.\n');
       edge_color = color_coding(3,:);
       edge_width = edge_widths(3);
   end
   plot3( X(1,edges(:,i)), X(2,edges(:,i)), X(3,edges(:,i)), ...
       '-', 'LineWidth', edge_width, 'Color', edge_color );
end

% finally plot triangles
triangles = K{3};
n_triangles = size(triangles,2);
for i = 1:n_triangles
    triangle_colors = sort(comp(triangles(:,i)));
    if sum(triangle_colors==1)
        triangle_color = [0 0 1];
        triangle_alpha = face_weights (1);
    elseif sum(triangle_colors==3)
        triangle_color = [0 .8 0];
        triangle_alpha = face_weights (2);
    else
        triangle_color = [0 .8 0];
        triangle_alpha = face_weights (2);
        fprintf('warning: invalid triangle detected.\n');
    end
    fill3 ( X(1,triangles(:,i)), X(2,triangles(:,i)), ...
        X(3,triangles(:,i)), triangle_color, 'EdgeColor', 'none', ...
        'FaceAlpha', triangle_alpha );
    hold on
end

axis equal
axis off
hold off
    