function K = triangulate_surface ( X, D, ints, nbhds, ...
    include_neighbors, make_plots )
% function K = triangulate_surface ( X, D, ints, nbhds, ...
%   include_neighbors, make_plots )
% This function implements an incremental algorithm for triangulation
% of a surface given points sampled from some object.  The algorithm 
% is loosely based on
%
%   D. Freedman (2007), "An Incremental Algorithm for Reconstruction of
%   Surfaces of Arbitrary Codimension", Computational Geometry 36: 106-116.
%
% INPUT: X -- a d x n matrix containing points sampled from the surface
%             (columns are points)
%        D -- a n x n matrix with pairwise distances between points
%             in X (e.g. could be geodesic distance)
%        ints -- indices into X giving points on intersections
%        nbhds -- cell array with neighborhoods of each point in X
%                  (as returned by surface_nbhds)
%        include_neighbors (optional) -- true to include graph neighbors
%                                        defaults to true, disable
%                                        for manifolds with boundary
%        make_plots (optional) -- show plots of progress with user pauses,
%                                 defaults to false
%
% OUTPUT: K -- a simplicial complex triangulating the surface, with
%              K{1} specifying points, K{2} specifying edges, and
%              K{3} specifying triangles.  For lines and triangles
%              indices are in order from top to bottom -- no orientation
%              is described.
%
% NOTES:
% 1. This algorithm can handle 2D manifolds and 2D manifolds with boundary.
% 2. At present we are self-constrained to dimension 2, although the
%    approach could be used in any dimension.  The only difficulty is
%    in computing circumdiameters for >3.
% 3. D can be either full or sparse.  If sparse, an entry of 0 indicates
%    that two nodes are not connected.  In any case, we assume that
%    D(i,i) = 0 for all i, and that D(nbhd_i,nbhd_i) is a full
%    matrix (as returned by sparse_distance.m, for example).
%
% NOTE: Can only use Euclidean distance when using include neighbors
%       option (see code).
%
% S. Martin
% 12/10/2008

% initialize graph neighbors
if nargin < 5
    include_neighbors = true;
end

% initialize plotting default, if necessary
if nargin < 6
    make_plots = false;
end

% step 1 is to triangulate all the intersections
% (and initialize the complex to include all points)
K = triangulate_intersections ( X, D, ints, nbhds, make_plots );

% step 2 is to triangulate the non-intersections
% incrementally per neighborhood
fprintf('Triangulating surface ...\n     ');
num_points = size(X,2);
points_to_do = ones(1,num_points);
points_to_do (ints) = 0;
points_to_do_next = zeros(1,num_points);
points_to_do_next(find(points_to_do,1)) = 1;
while sum(points_to_do)
    
    % get next point in line
    c = find(points_to_do_next,1);
    
    % identify neighborhood
    nbhd = nbhds{c};
    
    if include_neighbors
      % expand neighborhood to include anyone already connected to c
      edges_containing_c = K{2}(:,find(sum(K{2}==c,1))); 
      neighbors_of_c = edges_containing_c(find(edges_containing_c~=c))';
      nbhd = union (nbhd,neighbors_of_c);
      
      % modify distance matrix, if new neighbors were added
      % NOTE: this now implies Euclidean distance!
      if ~isempty(neighbors_of_c)
          D(nbhd,nbhd) = L2_distance ( X(:,nbhd),X(:,nbhd), 1 );
      end
    end
    
    % project neighborhood to tangent plane
    U = project_nbhd ( D, nbhd, 2 );
    
    % get subcomplex of K intersecting neighborhood
    L = filter_nbhd ( nbhd, K, 2 );
    
    % show neighborhood that we are using
    if make_plots
      plot_complex ( K, X, U, c );
    end
    
    % populate neighborhood complex & get points to examine next
    nbhd_complex = construct_nbhd  ( L, U, D, c, X, K, make_plots );

    % add neighorhood to global complex
    K = add_complex ( K, nbhd_complex );
  
    % find new possible neighbors
    edges_containing_c = K{2}(:,find(sum(K{2}==c,1))); 
    neighbors_of_c = edges_containing_c(find(edges_containing_c~=c));
    
    % update progress
    points_to_do(c) = 0;
    points_to_do_next(neighbors_of_c) = 1;
    points_to_do_next = points_to_do.*points_to_do_next;
    
    % if no points to do next, but some points to do,
    % we may have two or more disconnected sets of surfaces
    % (in that case just jump to a new point to do)
    if (~sum(points_to_do_next)) & sum(points_to_do)
        points_to_do_next(find(points_to_do,1)) = 1;
    end
    
    % output progress
    points_done = num_points - sum(points_to_do);
    if mod(points_done,10)==0
        fprintf('.');
    end
    if mod(points_done,100)==0
        fprintf(' %d\n     ',points_done);
    end
    
end
fprintf('\n');
if isempty(ints)
    plot_complex ( K, X );
else
    plot_int_complex ( X, K, ints );
end
axis off
