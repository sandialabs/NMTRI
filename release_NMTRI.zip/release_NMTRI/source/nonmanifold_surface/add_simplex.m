function K = add_simplex ( L, tau )
% function K = add_simplex ( L, tau )
% This function adds the simplex tau (can be any dimension)
% the the complex L, returning the results in K (i.e. K = L + tau).
%
% INPUTS: L -- complex of the form L{1} = points, L{2} = edges (columns),
%              etc.
%         tau -- (sorted) column vector containing new simplex
%
% OUTPUTS: K -- new complex including both L and tau.
%
% S. Martin
% 11/11/2008

for i = length(tau):-1:1
    faces = nchoosek(1:length(tau),i)';
    for j = 1:size(faces,2)
        if isempty(L{i})
            L{i} = tau(faces(:,j));
        else
            L{i} = union ( L{i}', tau(faces(:,j))', 'rows' )';
        end
    end
end

K = L;