function areas = area_tri ( edge_lengths )
% function areas = area_tri ( edge_lengths )
% Returns the areas of the given triangles using Heron's distance
% formula.
%
% INPUTS: edge_lengths -- lengths of sides of triangles
%
% OUTPUT: areas -- row vector with area of each triangle
%
% S. Martin
% 9/30/2008

% sort to use numerically stable Heron's formula
edge_lengths = sort ( edge_lengths, 1 );

% a >= b >= c
a = edge_lengths(3,:);
b = edge_lengths(2,:);
c = edge_lengths(1,:);

% compute areas
areas = 1/4*sqrt((a+(b+c)).*(c-(a-b)).*(c+(a-b)).*(a+(b-c)));

% make sure no complex numbers have appeared
areas = abs(areas);