function L = filter_nbhd ( nbhd, K, dim_nbhd )
% function L = filter_nbhd( nbhd, K, dim_nbhd )
% This function identifies a subcomplex of K which intersects the
% current neighborhood.
%
% INPUTS: nbhd -- indices of neighborhood
%         K -- complex constructed so far
%         dim_nbhd -- dimension of neighborhood
%
% OUTPUT: L -- subcomplex of K in the neighborhood
%
% S. Martin
% 9/30/2008

% identify subcomplex which already includes points in neighborhood,
% starting at neighborhood dimension
for i = 1:(dim_nbhd+1)
    sub_inds = find(sum(ismember(K{i},nbhd),1)==i);
    if ~isempty(sub_inds)
        L{i} = K{i}(:,sub_inds);
    else
        L{i} = [];
    end
end

% for efficiency, we only keep points not in edges, edges not in triangles
if ~isempty(L{2})
    L{1} = L{1}(:,find(sum(~ismember(L{1},L{2}(:)),1)));
end
if ~isempty(L{3})
    L{2} = L{2}(:,find(~ismember(L{2}',[L{3}([1 2],:),...
        L{3}([1 3],:),L{3}([2 3],:)]','rows')));
end