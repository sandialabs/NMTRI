function boundaries = find_boundaries ( faces, U )
% function boundaries = find_boundaries ( faces, U )
% This routine tests whether or not the given faces are
% boundaries in the projection U.
%
% INPUTS: faces -- matrix with columns as indices of faces into U
%         U -- projection of neighborhood
%
% OUTPUT: boundaries -- vector same length as number of faces
%                       with 1 for boundary, 0 for no boundary
%
% S. Martin
% 9/25/2008

% set machine epsilon for determining boundary
boundary_eps = 10^-8;

% get number of faces, vertices per face & neighborhood
[num_verts, num_faces] = size(faces);
Gamma = find(~isnan(U(1,:)));

% assume a face is not a boundary
boundaries = zeros(1,num_faces);

% check each face
for j = 1:num_faces
    
    % create face_space matrix b-a,c-a,...
    for i = 1:num_verts
        face_space(:,i) = U(:,faces(i,j)) - U(:,faces(1,j));
    end
    
    % null space of this matrix is projection vector
    boundary_proj = null (face_space');
    
    % project all points in neighborhood
    projection_U = boundary_proj'*(U(:,Gamma) - ...
        repmat(U(:,faces(1,j)),1,length(Gamma)));
    
    % if everything is on one side of zero it is a boundary
    if prod(double(projection_U<=boundary_eps)) || ...
            prod(double(projection_U>=-boundary_eps))
        boundaries(j) = 1;
    end
    
end
