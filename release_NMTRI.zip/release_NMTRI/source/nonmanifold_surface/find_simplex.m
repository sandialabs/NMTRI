function  tau = find_simplex ( L, U, c )
% function tau = find_simplex ( L, U, c )
% This routine finds the first occurence of a simplex which has
% only 1 bounding higher dimensional simplex and is
% not part of the boundary.  For example, if U is 2D then 
% tau is an edge with only one co-incident triangle.  In addition
% tau cannot be a boundary edge.
%
% INPUT: L -- simplicial complex in neighborhood 
%        U -- projected neighborhood (note U(:,~nbhd) = NaN)
%        c -- center of neighborhood
%
% OUTPUT: tau -- new simplex ( has dimension one less than U )
%                containing c
%
% NOTES:
% 1.  This algorithm assumes that there is at least one simplex of
%     the dimension of U (thus initialize_nbhd.m should be
%     called prior to this routine).
% 2.  The algorithm assumes that the simplex indices are sorted
%     from top to bottom in each column.
%         
% S. Martin
% 9/24/2008

% dimension of U is index into L{}
n = size(U,1);

% look at next higher dimension in L for bounding simplices
face_inds = nchoosek ( (1:(n+1)), n )';
num_faces = size(face_inds,2);
num_simplices = size(L{n+1},2);
neighbors = zeros( n, num_faces*num_simplices );
for i = 1:num_faces
  faces (:, ((i-1)*num_simplices+1):(i*num_simplices) ) = ...
      L{n+1}(face_inds(:,i),:);
end

% sort and look for non-paired faces
[sorted_faces, sorted_face_inds] = sortrows (faces');
non_pair = [1;sum(sorted_faces(2:end,:)~=sorted_faces(1:end-1,:),2);1]';
non_pair_inds = sorted_face_inds(find(non_pair(2:end).*...
    non_pair(1:end-1)));

% weed out boundary faces
boundaries = find_boundaries ( faces (:,non_pair_inds), U );
non_pair_inds = non_pair_inds (find(~boundaries));

% keep only faces containing c
faces_containing_c = sum(ismember(faces (:,non_pair_inds),c),1);
if sum(faces_containing_c)
    tau = faces(:,non_pair_inds(find(faces_containing_c,1)));
else
    tau = [];
end