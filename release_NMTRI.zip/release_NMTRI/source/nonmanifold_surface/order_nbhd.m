function Gamma = order_nbhd ( delta, U, D, L )
% function Gamma = order_nbhd ( delta, U, D, L )
% Selects and orders the points neighboring the simplex
% delta which maximizes 1/circumdiameter.
%
% INPUTS: delta -- simplex indices (column)
%         U -- neighborhood projection
%         D -- pairwise distances
%         L -- complex intersecting neighborhood U
%
% OUTPUT: Gamma -- neighborhood indices ordered
%                  from best to least quality
%
% NOTE: This code uses specific formulas for quality
%       of lines, triangles, and tetrahedra so can
%       not be used for problems >3D.
%
% S. Martin
% 9/30/2008

% deg_eps is machine epsilon for considering area or
% volume to be degenerate
deg_eps = 10^-8;

% get neighborhood not including face
Gamma = find(~isnan(U(1,:)));
not_in_delta = find(~ismember(Gamma,delta));
Gamma = Gamma( not_in_delta );

% eliminate points leading to elements already in L
new_simps = sort([repmat(delta,1,length(Gamma));Gamma],1);
simps_dim = size(new_simps,1);
[existing_simps,inds_L,inds_simps] = ...
    intersect ( L{simps_dim}', new_simps', 'rows' );
if ~isempty(existing_simps)
  keep_Gamma = ones(size(Gamma));
  keep_Gamma(inds_simps) = 0;
  Gamma = Gamma(find(keep_Gamma));
end

% we compute quality measure for different cases
dim_delta = length(delta)-1;
switch dim_delta
    
    case 0
        % for a point we just add nearest point
        quality_measure = -D(delta,Gamma);
        
    case 1
        % for lines we compute 1/circumdiameter
        edge_lengths = [D(delta,Gamma); ...
            repmat(D(delta(1),delta(2)),1,length(Gamma))];
        area_triangles = area_tri ( edge_lengths );
        quality_measure = 2*area_triangles./(prod(edge_lengths,1));
        
    case 2
        % for triangles we compute 1/circumdiameter
        base_lengths = [D(delta(1),delta(2)); ...
                        D(delta(2),delta(3)); ...
                        D(delta(1),delta(3))];
        edge_lengths = [D(delta,Gamma); ...
            repmat(base_lengths,1,length(Gamma))];
        vol_tetrahedrons = vol_tetra ( edge_lengths );
        aa_prime = edge_lengths(1,:).*edge_lengths(5,:);
        bb_prime = edge_lengths(2,:).*edge_lengths(6,:);
        cc_prime = edge_lengths(3,:).*edge_lengths(4,:);
        A = area_tri ( [aa_prime;bb_prime;cc_prime] );
        quality_measure = 3*vol_tetrahedrons./A;
            
    otherwise
        error ('attempted to compute circumdiameter for simplex >3D.');
end

% maximize quality measure
[sorted_QM, Gamma_order] = sort ( -quality_measure );
Gamma = Gamma(Gamma_order);

% eliminate degenerate points from consideration
if sum(abs(sorted_QM) <= deg_eps)
    Gamma = Gamma (find(abs(sorted_QM) > deg_eps));
end
