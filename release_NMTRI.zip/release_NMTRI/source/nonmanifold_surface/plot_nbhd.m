function plot_nbhd ( U, L, c, tau, v )
% function plot_nbhd ( U, L, c, tau, v )
% This subroutine produces a plot in figure 2 of the 
% current neighborhood under evaluation.
%
% INPUTS: U -- projection of potential points into tangent plane
%         L -- subcomplex of K interseting Gamma
%         c -- center point of neighborhood
%         tau -- edge or face of proposed new simplex
%         v -- (optional) [tau;v] make up proposed new simplex
%
% OUTPUT: Figure 2 -- showing projection into tangent plane
%
% NOTES: 
% 1. We assume that U is 1-3D.
%
% S. Martin
% 11/05/2008

% plot neighborhood in figure 2
figure(2)

% get neighborhood
Gamma = find(~isnan(U(1,:)));

% plot projection (different plots for different dimensions)
dim_U = size(U,1);
switch dim_U
    case 1
        % plot neighborhood and center point
        plot(U(1,Gamma),zeros(1,length(Gamma)),'go');
        hold on
        plot(U(1,c),0,'gx','MarkerSize',12,'LineWidth',3);
        
        % plot subcomplex L -- points and edges
        plot(U(1,L{1}),zeros(1,length(L{1})),'b.');
        for i = 1:size(L{2},2)
            edge = L{2}(:,i);
            plot(U(1,edge),[0 0],'b.-');
        end
        
        % plot current simplex tau
        plot(U(1,tau),0,'mo');
        
        % plot vertex v if available
        if nargin == 5
            plot(U(1,v),0,'ro');
            for i = 1:length(tau)
                plot(U(1,[tau(i),v]),[0 0],'r-');
            end
        end
        
    case 2
        % plot neighborhood and center point
        plot (U(1,Gamma), U(2,Gamma), 'go');
        hold on
        plot (U(1,c), U(2,c), 'gx', 'MarkerSize', 12, ...
            'LineWidth', 3 );
        
        % plot subcomplex L -- points, edges, and triangles
        plot(U(1,L{1}),U(2,L{1}),'b.');
        for i = 1:size(L{2},2)
          edge = L{2}(:,i);
          plot(U(1,edge),U(2,edge),'b.-');
        end
        for i = 1:size(L{3},2)
          triangle = L{3}(:,i);
          fill ( U(1,triangle)', U(2,triangle)', ...
              [0 1 1], 'EdgeColor', 'b', 'FaceAlpha', .7);
        end

        % plot current simplex tau
        plot (U(1,tau),U(2,tau),'mo');
        if length(tau) >= 2
            delta_edges = nchoosek(1:length(tau),2)';
            for i = 1:size(delta_edges,2)
                plot(U(1,tau(delta_edges(:,i))),...
                    U(2,tau(delta_edges(:,i))),'m-');
            end
        end
        
        % plot vertex v if available
        if nargin == 5
            plot(U(1,v),U(2,v),'ro');
            for i = 1:length(tau)
                plot(U(1,[tau(i),v]),U(2,[tau(i),v]),'r-');
            end
        end
        
    case 3
        % plot neighborhood and center point
        plot3 (U(1,Gamma),U(2,Gamma),U(3,Gamma), 'go' );
        hold on
        plot3 (U(1,c), U(2,c), U(3,c), 'gx','MarkerSize',12,...
            'LineWidth', 3);
        
        % plot subcomplex L -- points, edges, and triangles
        plot3(U(1,L{1}),U(2,L{1}),U(3,L{1}),'b.');
        for i = 1:size(L{2},2)
            edge = L{2}(:,i);
            plot3(U(1,edge),U(2,edge),U(3,edge),'b.-');
        end
        
        % for triangles, we merge lone triangles, and triangles
        % from tetrahedrons to prevent plotting more than once
        triangles = L{3};
        for i = 1:size(L{4},2)
            triangles = union ( triangles', L{4}([1 2 3],:)', 'rows' )';
            triangles = union ( triangles', L{4}([1 2 4],:)', 'rows' )';
            triangles = union ( triangles', L{4}([1 3 4],:)', 'rows' )';
            triangles = union ( triangles', L{4}([2 3 4],:)', 'rows' )';
        end
        for i = 1:size(triangles,2)
            fill3 ( U(1,triangles(:,i)), U(2,triangles(:,i)), ...
                U(3,triangles(:,i)), [0 1 1], 'EdgeColor', 'b', ...
                'FaceAlpha', .7);
        end
        
        % plot current simplex tau
        plot3 (U(1,tau),U(2,tau),U(3,tau),'mo');
        if length(tau) >= 2
            delta_edges = nchoosek(1:length(tau),2)';
            for i = 1:size(delta_edges,2)
                plot3(U(1,tau(delta_edges(:,i))),...
                    U(2,tau(delta_edges(:,i))),...
                    U(3,tau(delta_edges(:,i))),'m-');
            end
        end
        
        % plot vertex v if available
        if nargin == 5
            plot3(U(1,v),U(2,v),U(3,v),'ro');
            for i = 1:length(tau)
                plot3(U(1,[tau(i),v]),U(2,[tau(i),v]),U(3,[tau(i),v]),'r-');
            end
        end
        
    otherwise
        error ('Cannot process >3D data.');
end

hold off