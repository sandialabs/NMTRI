function plot_complex ( K, X, U, c, L )
% function plot_complex ( K, X, U, c, L )
% This subroutine produces a 3d plot of the data
% and complex inferred.
%
% INPUTS: K -- complex, with triangles
%         X -- original datapoints (columns are vectors)
%         U -- projection of potential points into tangent plane
%         c -- center point of neighborhood
%
% OUTPUT: Figure 1 -- showing original dataset and K
%
% NOTE: We assume that X is 3D.
%
% S. Martin
% 11/05/2008

% plot data points
figure(1)
clf
plot3(X(1,:),X(2,:),X(3,:),'.','Color',[.9 .9 .9]);
axis equal

hold on

% set background to white
h = gcf;
set(h,'Color',[1 1 1]);

% plot edges
for i = 1:size(K{2},2)
    edge = K{2}(:,i);
    plot3(X(1,edge),X(2,edge),X(3,edge),'-','Color',[.9 .9 .9]);
end

% fill triangles (if present)
if length(K)>=3
    for i = 1:size(K{3},2)
        triangle = K{3}(:,i);
        fill3(X(1,triangle),X(2,triangle),X(3,triangle), ...
            [0 0 1], 'EdgeColor',[.9 .9 .9], 'FaceAlpha', .25);
    end
end

if nargin > 2
    % plot neighborhood & center point
    Gamma = find(~isnan(U(1,:)));
    plot3(X(1,Gamma),X(2,Gamma),X(3,Gamma),'ko','MarkerSize',6,'MarkerFaceColor','k','EraseMode','none');
            for i = 1:size(L{2},2)
          edge = L{2}(:,i);
          plot3(X(1,edge),X(2,edge),X(3,edge),'k-','LineWidth',1);
            end
        
                    for i = 1:size(L{3},2)
          triangle = L{3}(:,i);
          fill3 ( X(1,triangle)', X(2,triangle)', X(3,triangle)', ...
              [0 0 1], 'FaceAlpha', 0, 'LineWidth', 1);
                    end
            plot3(X(1,c), X(2,c), X(3,c), 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r', 'EraseMode','none');

end
axis off
hold off
view(-70,0)