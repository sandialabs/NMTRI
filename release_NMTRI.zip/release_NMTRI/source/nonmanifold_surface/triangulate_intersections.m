function K = triangulate_intersections ( X, D, ints, nbhds, make_plots )
% function K = triangulate_intersections ( X, D, ints, nbhds, make_plots )
% This routine serves to initialize the complex K by putting each
% point in K and triangulating all of the intersection points.
%
% INPUT: X -- a d x n matrix containing points sampled from the surface
%             (columns are points)
%        D -- a n x n matrix with pairwise distances between points
%             in X (e.g. could be geodesic distance)
%        ints -- indices into X giving points on intersections
%        nbhds -- cell array with neighborhoods of each point in X
%                  (as returned by surface_nbhds)
%        make_plots -- show plots of progress with user pauses
%
% OUTPUT: K -- a simplicial complex triangulating the surface, with
%              K{1} specifying points, K{2} specifying edges, and
%              K{3} specifying triangles.  For lines and triangles
%              indices are in order from top to bottom -- no orientation
%              is described.
%
% S. Martin
% 12/10/2008

% initialize complex to include all points 
num_points = size(X,2);
K{1} = 1:num_points;
K{2} = [];
K{3} = [];

% if there aren't any intersections then we are done
if isempty(ints)
    return
end

% identify intersection points
num_points = size(X,2);
points_to_do = zeros(1,num_points);
points_to_do (ints) = 1;
points_to_do_next = zeros(1,num_points);
points_to_do_next(find(ints,1)) = 1;
    
% triangulate intersection points using incremental algorithm
% (this should not take long)
fprintf('Triangulating intersections ...\n');
while sum(points_to_do)
    
    % get next point in line
    c = find(points_to_do_next,1);
    
    % identify neighborhood
    nbhd = nbhds{c};
    
    % project neighborhood to tangent plane
    % (intersection neighborhoods are assumed to be 1D)
    U = project_nbhd ( D, nbhd, 1 );
    
    % get subcomplex of K intersecting neighborhood
    L = filter_nbhd ( nbhd, K, 2 );
    
    % show neighborhood that we are using
    if make_plots
      plot_complex ( K, X, U, c );
    end
    
    % populate neighborhood complex & get points to examine next
    nbhd_complex = construct_nbhd  ( L, U, D, c, X, K, make_plots );

    % add neighorhood to global complex
    K = add_complex ( K, nbhd_complex );
  
    % find new possible neighbors
    edges_containing_c = K{2}(:,find(sum(K{2}==c,1))); 
    neighbors_of_c = edges_containing_c(find(edges_containing_c~=c));
    
    % update progress
    points_to_do(c) = 0;
    points_to_do_next(neighbors_of_c) = 1;
    points_to_do_next = points_to_do.*points_to_do_next;
    
    % if no points to do next, but some points to do,
    % we may have two or more disconnected sets of intersections
    % (in that case just jump to a new point to do)
    if (~sum(points_to_do_next)) & sum(points_to_do)
        points_to_do_next(find(points_to_do,1)) = 1;
    end
        
end

