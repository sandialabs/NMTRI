function U = project_nbhd ( D, nbhd, nbhd_dim )
% function U = project_nbhd ( D, nbhd, nbhd_dim )
% This function computes the projection of a neighborhood
% onto the tangent plane determined using MDS.
%
% INPUTS: D -- pairwise distance matrix
%         nbhd -- indices of neighborhood in D
%         nbhd_dim -- dimension to use for projection
%
% OUTPUT: U -- the neighborhood points projected onto
%              the tangent plane using MDS.
%
% S. Martin
% 9/18/2008

% projection is obtained using multidimensional scaling
D_nbhd = D(nbhd,nbhd);
n = length(nbhd);
P = eye(n) - repmat(1/n,n,n);
B = P * (-.5 * D_nbhd .* D_nbhd) * P;
[V E] = eig((B+B')./2); % guard against spurious complex e-vals from roundoff
[sigma, inds] = sort(diag(E));
sigma = flipud(sigma); inds = flipud(inds); % sort descending

% we only project local neighborhood; everything else is NaN
U = nan(nbhd_dim,size(D,2));
U(:,nbhd) = (V(:,inds(1:nbhd_dim))*diag(sqrt(sigma(1:nbhd_dim))))';

% check that find(~isnan(U(1,:)) == nbhd
if sum(abs(sort(find(~isnan(U(1,:))))-sort(nbhd)))
    nbhd
    error ('ambiguous nbhd.\n');
    
end