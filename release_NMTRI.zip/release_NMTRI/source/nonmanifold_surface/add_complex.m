function K = add_complex ( L, N )
% function K = add_complex ( L, N ) 
% This function adds the complex N to the complex L and
% returns the results in the complex K (so K = L + N).
%
% INPUTS: L -- complex of the form L{1} = points, L{2} = edges (columns),
%              etc.
%         N -- another complex
%
% OUTPUTS: K -- new complex including both L and N
%
% S. Martin
% 11/11/2008

% get dimension of N (highest non-empty cell)
for i = length(N):-1:1
    if ~isempty(N{i})
        dim_N = i;
        break
    end
end

% merge L and N into L
for i = dim_N:-1:1
    % for each dimension add all smaller dimensional sub-simplices to L
    for j = i:-1:1
        faces = nchoosek(1:i,j)';
        for k = 1:size(faces,2)
            if isempty(L{j})
                L{j} = N{i}(faces(:,k),:);
            else
                L{j} = union ( L{j}', N{i}(faces(:,k),:)', 'rows' )';
            end
        end
    end
end

% now L and N become K
K = L;