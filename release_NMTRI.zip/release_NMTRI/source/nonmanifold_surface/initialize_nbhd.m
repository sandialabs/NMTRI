function tau = initialize_nbhd ( L, U, D, c, X, K, make_plots  )
% function tau = initialize_nbhd ( L, U, D, c, X, K, make_plots )
% Locates a simplex tau with same dimension of U.  Tau may or may
% not already exist in L (if there is a tau in L then that tau is
% taken, otherwise a tau is constructed).
%
% INPUTS: L -- complex intersecting neighborhood given by U
%         U -- projection of neighborhood
%         D -- pairwise distance matrix
%         c -- center point of neighborhood
%         X -- original points (in case of diagnosing failure
%              or to show plots)
%         K -- full complex (for plots)
%         make_plots -- true to step through showing plots
%                       at each iteration
%
% OUTPUTS: tau -- simplex with dimension of U containing c
%
% NOTE: We assume that all points in U are already in L.
%
% S. Martin
% 9/30/2008

% check to see if we can get tau from L containing c
dim_U = size(U,1);
if ~isempty(L{dim_U+1})
    tau_containing_c = sum(ismember (L{dim_U+1},c),1);
    if sum(tau_containing_c)
        tau = L{dim_U+1}(:,find(tau_containing_c,1));
        return
    end
end

% otherwise we have to construct tau (a mini version of
% our main algorithm)

% look for highest dimensional available face delta containing c
delta_found = 0;
for i = (dim_U+1):-1:1
    if ~isempty(L{i})
        delta_containing_c = sum(ismember(L{i},c),1);
        if sum(delta_containing_c)
            delta = L{i}(:,find(delta_containing_c,1));
            delta_found = 1;
            break
        end
    end
end

% if no simplex was added, then error
if ~delta_found
    plot_complex ( K, X, U, c );
    plot_nbhd ( U, L, c );
    error ('Could not find delta to initialize neighborhood.');
end

% now construct tau starting with the face delta
for i = length(delta):dim_U
    
    % get & sort neighborhood not including face
    Gamma = order_nbhd ( delta, U, D, L );
    
    % find new simplex tau
    tau_found = 0;
    for j = 1:length(Gamma)
        tau = sort([delta;Gamma(j)]);
        if ~intersect_simplex ( tau, L, U )
            tau_found = 1;  
            
            % show results, if desired
            if make_plots
                plot_nbhd ( U, L, c, delta, Gamma(j) );
                pause
            end
                
            delta = tau;
            break;
        end
    end
    
    % if no simplex was added, then error
    if ~tau_found
        plot_complex ( K, X, U, c );
        plot_nbhd ( U, L, c, delta );
        error ('Could not initialize neighborhood.');
    end
    
end