function nbhd_complex = construct_nbhd ( L, U, D, c, X, K, make_plots )
% function nbhd_complex = construct_nbhd ( L, U, D, c, X, K, make_plots )
% Construct a complex in the neighborhood provided while
% preserving whatever simplices are already present in the neighborhood.
%
% INPUTS: L -- subcomplex in neighborhood
%         U -- projection of neighborhood
%         D -- pairwise distance matrix
%         c -- index of center point in neighborhood
%         X -- original points (in case of diagnosing failure
%              or to show plots)
%         K -- full complex (for plots)
%         make_plots -- true to step through showing plots
%                       at each iteration
%
% OUTPUT: nbhd_complex -- complex construct for the neighborhood
%
% S. Martin
% 9/30/2008

% seed neighborhood with simplex, if necessary
tau = initialize_nbhd ( L, U, D, c, X, K, make_plots );
L = add_simplex ( L, tau );

% incrementally construct neighborhood complex
% get face of simplex to add
delta = find_simplex ( L, U, c );
while ~isempty (delta)
    
    % order neighborhood candidates for increase efficiency
    % when testing for simplex intersection
    Gamma = order_nbhd ( delta, U, D, L );
    
    % add new simplex to L
    tau_added = 0;
    for i = 1:length(Gamma)
        tau = sort([delta;Gamma(i)]);
        if ~intersect_simplex ( tau, L, U )
            tau_added = 1;
            
            % show results, if desired
            if make_plots
                plot_nbhd ( U, L, c, delta, Gamma(i) );
                pause
            end
            
            L = add_simplex ( L, tau );
            break;
        end
    end
    
    % if a face was found, but no simplex was added, then quit
    if ~tau_added & ~isempty(delta)
        plot_complex ( K, X, U, c );
        plot_nbhd ( U, L, c, delta );
        %error ('Could not add simplex.');
    end
    
    % get face of simplex to add
    delta = find_simplex ( L, U, c );
    
end

nbhd_complex = L;