function [indices, nbhds, nbhd_dim] = surface_intersection ( Y, nbhd_e, dim_thresh, ...
    plane_thresh, good_nbhd, int_e, rank_tol, use_optim, make_plots )
% function indices = surface_intersection ( X, nbhd_e, dim_thresh, ...
%     plane_thresh, good_nbhd, int_e, rank_tol, 0, make_plots )
% This function returns the indices into X of any points near a
% surface intersection.  The algorithm uses a uniform subsampling of
% the data (X) then proceeds to project each neighborhood, resolving
% possible intersections by fitting two planes when the projection is 3D.
%
% INPUTS: X -- data with points as columns
%         nbhd_e -- epsilon radius for local neighborhood
%         dim_thresh -- eigenvalue threshold (fraction) to
%                       determine local dimension
%         plane_thresh -- intersecting planes fit quality in
%                         terms of mean distance
%         good_nbhd -- maximum distance from neighborhood center
%                      to intersecting line to use neighborhood for
%                      full projection (e.g. 2*min_dist)
%         int_e -- epsilon radius for determining when a point is close
%                  enough to a surface intersection to be counted
%         rank_tol -- rank tolerance to pass to fit_planes.m
%         use_optim -- true to call matlab optimization routine
%                      (defaults to false)
%         make_plots -- (optional) show plots as algorithm progresses
%                       0: no plots (default)
%                       1: all plots
%                       2: only 3D plots
%
% OUTPUT: indices -- indices into X of intersections
%
% S. Martin
% 12/4/2008

% set optimization default
if nargin < 8
    use_optim = 0;
end

% set plotting default
if nargin < 9
    make_plots = 0;
end

% go through each point of Y looking for intersections
num_Y = size(Y,2);
XX = sum(Y.*Y,1);
nbhd_e_sq = nbhd_e^2;
indices = [];
fprintf('Computing neighborhoods ...\n     ');
for i = 1:num_Y
    
    % get neighborhood of point i (including i)
    yi = Y(:,i);
    dist_i = XX - 2*yi'*Y + yi'*yi;
    dist_nbhd_i = find(dist_i<nbhd_e_sq);
    [sort_nbhd, sort_nbhd_ind] = sort(dist_i(dist_nbhd_i));
    nbhd = dist_nbhd_i(sort_nbhd_ind);
       
    % estimate dimension of neighborhood
    num_nbhd = length(nbhd);
    mean_nbhd = mean(Y(:,nbhd),2);
    mean_sub_nbhd = Y(:,nbhd) - repmat(mean_nbhd,1,num_nbhd);
    [u,s,v] = svd(mean_sub_nbhd,'econ');
    
    s = diag(s).^2; % use eigenvalues instead of singular values
                    % since they are related to mse       
    dim_error= 1-cumsum(s)/sum(s);    % normalize to fraction
    nbhd_dim = find(dim_error<dim_thresh,1);

    % if not two or three dimensional then quit
    if (nbhd_dim ~= 2) && (nbhd_dim ~= 3)
        error ('neighborhood of dimension < 2 or > 3 detected.');
    end
    
    % if three dimensional then fit planes through data
    good_fit = true;
    if nbhd_dim == 3
        
        % projection is given by u matrix
        proj_nbhd = u(:,1:nbhd_dim)'*(Y(:,nbhd) - repmat(mean_nbhd,1,num_nbhd));
    
        % fit planes to neighborhood
        [coeffs, r3, r4, T2, dist_resid, factor_resid] = ...
            fit_planes ( proj_nbhd, rank_tol, use_optim );
            
        % final test for good fit
        if (r3 ~= 2) || (r4 ~=2) || (T2 > 0) || (dist_resid > plane_thresh)
            good_fit = false;
        end
        
        % compute intersection of planes 
        % we use Lagrange multiplier method of J. Krumm
        A = [2*eye(3), coeffs(:,1:3)'; coeffs(:,1:3), zeros(2)];
            
        % check that we don't have parallel planes
        if rank(A) < 5
            plot_intersection ( Y, i, nbhd, proj_nbhd, coeffs );
            error ('potential parallel planes.');
        end
            
        % compute point on plane closest to center of neighborhood
        point_on_plane_1 = coeffs(1,1:3)\(-coeffs(1,4));
        point_on_plane_2 = coeffs(2,1:3)\(-coeffs(2,4));
        b = [2*proj_nbhd(:,1); coeffs(1,1:3)*point_on_plane_1; ...
             coeffs(2,1:3)*point_on_plane_2];
             
        % solve for nearest point
        nearest_point = A\b;
        nearest_point = nearest_point(1:3);
            
        % how close is neighborhood center to nearest point on line?
        dist_nearest = norm ( nearest_point - proj_nbhd(:,1) );
            
        % if we are within the given threshold, we use to
        % determine the intersection
        found_intersection = false;
        if dist_nearest < good_nbhd
                
                % get points near intersection of planes & near
                % center of neighborhood (use good_nbhd threshold)
                dist_plane_1 = plane_distance ( proj_nbhd, coeffs(1,:) );
                dist_plane_2 = plane_distance ( proj_nbhd, coeffs(2,:) );
                dist_nearest_point = sqrt(sum((proj_nbhd - ...
                    repmat(nearest_point,1,num_nbhd)).^2));
                
                points_near_intersect = ...
                    find ((dist_plane_1 < int_e ) & ...
                          (dist_plane_2 < int_e ) & ...
                           dist_nearest_point < good_nbhd );
                       
                % record points in final output "indices" variable
                if isempty(indices)
                    indices = nbhd (points_near_intersect);
                else
                    indices = union ( indices, ...
                        nbhd(points_near_intersect) );
                end
                       
                % show points for plotting, if desired
                proj_near_intersect = proj_nbhd (:,points_near_intersect);
                
                % record that we found intersection points
                found_intersection = true;
  
        end
 
    end
    
    % show progress, if requested
    if (make_plots==1) || ((make_plots==2) && (nbhd_dim==3)) || ~good_fit
        if nbhd_dim == 2
            plot_intersection ( Y, i, nbhd, proj_nbhd );
        else if found_intersection
                plot_intersection ( Y, i, nbhd, proj_nbhd, ...
                    nbhd_e, coeffs, nearest_point, proj_near_intersect );
            else 
                plot_intersection ( Y, i, nbhd, proj_nbhd, ...
                    nbhd_e, coeffs, nearest_point );
            end
        end
        pause
    end

        
    % update user
    if ~mod(i,100)
        fprintf('.');
    end
    if ~mod(i,1000)
        fprintf(' (%d)\n     ',i);
    end
    
end
fprintf('\n');

% show final results in plot
%plot3(Y(1,:),Y(2,:),Y(3,:),'b.');
%hold on
%plot3(Y(1,indices),Y(2,indices),Y(3,indices),'r.');
%hold off

return % end main routine

function plot_intersection ( Y, i, nbhd, proj_nbhd, ...
    nbhd_e, coeffs, nearest_point, proj_near_intersect )
% Visualize current step in algorithm (presence of 
% coeffs and nearest point indicates 3D data)

% show neighborhood in full space
figure(1)
plot3(Y(1,:),Y(2,:),Y(3,:),'g.');
hold on
plot3(Y(1,i),Y(2,i),Y(3,i),'bx','LineWidth',3,'MarkerSize',12);
plot3(Y(1,nbhd),Y(2,nbhd),Y(3,nbhd),'bo');
hold off
        
% show projection of neighborhood
figure(2)
if nargin < 5
    plot(proj_nbhd(1,:),proj_nbhd(2,:),'bo');
    hold on
    plot(proj_nbhd(1,1),proj_nbhd(2,1),'bx','LineWidth',3,'MarkerSize',12);
    hold off
else
    plot3(proj_nbhd(1,:),proj_nbhd(2,:),proj_nbhd(3,:),'bo');
    hold on
    plot3(proj_nbhd(1,1),proj_nbhd(2,1),proj_nbhd(3,1),'bx',...
          'LineWidth',3,'MarkerSize',12);
      
    % draw planes
    axis_limits = axis;
    
    % plane 1
    four_points = nbhd_e*[-1 -1; 1 -1; 1 1; -1 1]';
    null_basis = null(repmat(coeffs(1,1:3),3,1));
    point_on_plane = coeffs(1,1:3)\(-coeffs(1,4));
    plane_points = null_basis*four_points+repmat(point_on_plane,1,4);
    fill3(plane_points(1,:),plane_points(2,:),plane_points(3,:),...
        [0 1 1],'FaceAlpha',.5);
    
    % plane 2
    null_basis = null(repmat(coeffs(2,1:3),3,1));
    point_on_plane = coeffs(2,1:3)\(-coeffs(2,4));
    plane_points = null_basis*four_points+repmat(point_on_plane,1,4);
    fill3(plane_points(1,:),plane_points(2,:),plane_points(3,:),...
        [0 1 1],'FaceAlpha',.5);
    
    % draw intersection 
    intersect_vector = cross(coeffs(1,1:3),coeffs(2,1:3))';
    intersect_vector = intersect_vector/norm(intersect_vector);
    points_on_line = [nearest_point - nbhd_e*intersect_vector, ...
                      nearest_point + nbhd_e*intersect_vector];
    plot3(points_on_line(1,:),points_on_line(2,:),...
        points_on_line(3,:),'k-');
    
    % plot nearest point on line to center
    plot3(nearest_point(1),nearest_point(2),nearest_point(3),'kx',...
        'MarkerSize',12);
    
    % plot all X projected onto nbhd
    if nargin == 8
      plot3(proj_near_intersect(1,:),proj_near_intersect(2,:),...
          proj_near_intersect(3,:),'r.');
    end
    
    hold off
end

function dist_plane = plane_distance ( X, coeffs )
% Computes the distance to the nearest plane for each point in X

num_X = size(X,2);
dist_plane = abs ( coeffs*[X;ones(1,num_X)] )./ ...
    repmat (sqrt(sum(coeffs(:,1:3).^2,2)),1,num_X);
