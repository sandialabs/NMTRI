function nbhd_dim = compute_nbhd_dim ( Y, inds, ints, nbhd_e )
% function nbhd_dim = compute_nbhd_dim ( X, inds, ints, nbhd_e )
% This function computes neighorhood dimension according to
% the criterion that all neighborhoods are 2D unless they
% contain and intersection, in which case they are 3D.
%
% INPUTS: X -- data with points as columns
%         inds -- indices of W into X (only compute nbhd_dim for W)
%         ints -- indices into X with intersections
%         nbhd_e -- neighborhood epsilon size
%
% OUTPUT: nbhd_dim -- vector with neighborhood dimension
%                     for each neighborhood of X
%
% S. Martin
% 4/1/2009

num_Y = size(Y,2);
fprintf('Computing neighborhood dimension ...\n     ');
num_inds = length(inds);

XX = sum(Y.*Y,1);
nbhd_e_sq = nbhd_e^2;

for i = 1:num_inds
    
    % get neighborhood of point i (including i)
    %dist_i = sqrt(sum((Y - repmat(Y(:,i),1,num_Y)).^2));
    %[sort_dist_i, ind_dist_i] = sort( dist_i );
    %nbhd = ind_dist_i(find(sort_dist_i<nbhd_e));

    % get neighborhood of point i (including i)
    yi = Y(:,inds(i));
    dist_i = XX - 2*yi'*Y + yi'*yi;
    nbhd = find(dist_i<nbhd_e_sq);
       
    % does the neighborhood contain an intersection?
    nbhd_dim(i) = 2;
    if ~isempty(intersect ( nbhd, ints ) )
        nbhd_dim(i) = 3;
    end
    
    if ~mod(i,1000)
        fprintf('.');
    end
    if ~mod(i,10000)
        fprintf(' %d\n     ',i);
    end
  
end
fprintf('\n');