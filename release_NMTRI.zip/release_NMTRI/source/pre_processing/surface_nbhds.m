function nbhds = surface_nbhds ( W, inds, ints, nbhd_e, ...
    dim_thresh, plane_thresh, rank_tol, use_optim, make_plots )
% function nbhds = surface_nbhds ( X, inds, ints, nbhd_e, ...
%    dim_thresh, plane_thresh, rank_tol, use_optim, make_plots )
% Surface_nbhds returns a sparse non-symmetric matrix specifying
% the neighbors of each point.
%
% INPUTS: X -- data, with points as columns (as returned by
%              sample_surface.m)
%         inds -- indices of W into X
%         ints -- indices into X of intersection points
%         nbhd_e -- epsilon radius for local neighborhood
%         dim_thresh -- eigenvalue threshold (fraction) to
%                       determine local dimension
%         plane_thresh -- intersecting planes fit quality in
%                         terms of mean distance
%         rank_tol -- rank tolerance to pass to fit_planes.m
%         use_optim -- true to call matlab optimization routine
%         make_plots -- (optional) show plots as algorithm progresses
%                       0: no plots (default)
%                       1: all plots
%                       2: only 3D plots
%
% OUTPUTS: nbhds -- cell array containing neighborhood information, with
%                       nbhds{i} = indices of all neighbors of
%                                  point i in W (including i)
%                   if i is an intersection point, the neighborhood
%                   only includes other intersection points, and
%                   all neighborhoods are 2D (points on intersecting
%                   planes are not counted)
%
% NOTE: If dim_thresh is a vector then it is assumed to be nbhd_dim
%       a vector containing pre-computing dimensions for each point
%       in W, accurate for the nbhd_e provided.
%
% S. Martin
% 12/10/2008

% set optimization default to false
if nargin < 8
    use_optim = 0;
end

% set plotting default
if nargin < 9
    make_plots = 0;
end

% check for nbhd_dim
nbhd_dim_precomputed = false;
if length(dim_thresh)>1
    nbhd_dim_precomputed = true;
end

% go through each point of W looking for neighborhoods
num_W = size(W,2);
num_inds = length(inds);
fprintf('Computing neighborhoods ...\n     ');
XX = sum(W.*W,1);
nbhd_e_sq = nbhd_e^2;
for i = 1:num_inds
    
    % get neighborhood of point i (including i)
    yi = W(:,inds(i));
    dist_i = XX - 2*yi'*W + yi'*yi;
    dist_nbhd_i = find(dist_i<nbhd_e_sq);
    [sort_nbhd, sort_nbhd_ind] = sort(dist_i(dist_nbhd_i));
    dist_nbhd = dist_nbhd_i(sort_nbhd_ind);
    
    % commpute projection of distance neighborhood
    num_nbhd = length(dist_nbhd);
    mean_nbhd = mean(W(:,dist_nbhd),2);
    mean_sub_nbhd = W(:,dist_nbhd) - repmat(mean_nbhd,1,num_nbhd);
    [u,s,v] = svd(mean_sub_nbhd,'econ');
        
    % estimate dimension
    s = diag(s).^2; % use eigenvalues instead of singular values
                    % since they are related to mse       
    dim_error= 1-cumsum(s)/sum(s);   % normalize to fraction
    if nbhd_dim_precomputed
        nbhd_dim = dim_thresh(i);
    else
        nbhd_dim = find(dim_error<dim_thresh,1);
    end
        
    % if not two or three dimensional then quit
    if (nbhd_dim ~= 2) && (nbhd_dim ~= 3)
        error ('neighborhood of dimension < 2 or > 3 detected.');
    end
    
    % if two dimensional then neighborhood corresponds to distance nbhd
    good_fit = true;
    if nbhd_dim == 2
        
       % if we are at an intersection point, then consider only
       % intersection point neighbors
       if ismember ( inds(i), ints )
                
            % get intersection points in neighborhood
            nbhds{i} = dist_nbhd ( find ( ...
                     ismember ( dist_nbhd, ints )));
       else
            nbhds{i} = dist_nbhd;
       end
    
    % if three dimensional then fit planes through data
    else
        
        % projection is given by u matrix
        proj_nbhd = u(:,1:nbhd_dim)'*(W(:,dist_nbhd) - repmat(mean_nbhd,1,num_nbhd));

        % fit planes to neighborhood
        [coeffs, r3, r4, T2, dist_resid, factor_resid] = ...
            fit_planes ( proj_nbhd, rank_tol, use_optim );
    
        % final test for good fit
        if (r3 ~= 2) || (r4 ~=2) || (T2 > 0) || (dist_resid > plane_thresh)
            good_fit = false;
        end
        
        % compute intersection of planes 
        % we use Lagrange multiplier method of J. Krumm
        A = [2*eye(3), coeffs(:,1:3)'; coeffs(:,1:3), zeros(2)];
            
        % check that we don't have parallel planes
        if rank(A) < 5
            plot_intersection ( Y, i, nbhd, proj_nbhd, coeffs );
            error ('potential parallel planes.');
        end
            
        % compute point on plane closest to center of neighborhood
        point_on_plane_1 = coeffs(1,1:3)\(-coeffs(1,4));
        point_on_plane_2 = coeffs(2,1:3)\(-coeffs(2,4));
        b = [2*proj_nbhd(:,1); coeffs(1,1:3)*point_on_plane_1; ...
             coeffs(2,1:3)*point_on_plane_2];
             
        % solve for nearest point
        nearest_point = A\b;
        nearest_point = nearest_point(1:3);
            
        % if we are at an intersection point, then consider only
        % intersection point neighbors
        if ismember ( inds(i), ints )
                
            % get intersection points in neighborhood
            nbhds{i} = dist_nbhd ( find ( ...
                ismember ( dist_nbhd, ints )));
                  
        % otherwise, we have to subtract out the competing plane
        else
                
            % compute distances from each point to each plane
            dist_plane = plane_distance ( proj_nbhd, coeffs );
                
            % determine which plane each point is on
            [min_dist_plane, min_dist_plane_ind] = min ( dist_plane );
                
            % keep points which are on the same plane as center
            % (or are intersection points)
            nbhds{i} = dist_nbhd ( find ( ...
                (min_dist_plane_ind == min_dist_plane_ind(1)) | ...
                    ismember ( dist_nbhd, ints ) ) );
                
        end
  
    end
    
    % show progress, if requested
    if (make_plots==1) || ((make_plots==2) && (nbhd_dim==3)) || ~good_fit
        if nbhd_dim == 2
            plot_intersection ( W, i, dist_nbhd, proj_nbhd, nbhds{i} );
        else
            plot_intersection ( W, i, dist_nbhd, proj_nbhd, nbhds{i}, ...
                nbhd_e, coeffs, nearest_point );
        end
        pause
    end

    % do planes fit the data?
    if ~good_fit
        fprintf('\ni = %d\n',i);
        fprintf('r3 = %d, r4 = %d, T2 = %f\n',r3,r4,T2);
        fprintf('Distance Residual = %f\n',dist_resid);
        fprintf('Factorization Residual = %f\n',factor_resid);
        error ('could not fit planes.');
    end
    
    % update user
    if ~mod(i,100)
        fprintf('.');
    end
    if ~mod(i,1000)
        fprintf(' (%d)\n     ',i);
    end
    
end
fprintf('\n');

return % end main routine

function plot_intersection ( Y, i, nbhd, proj_nbhd, nbhds_i, ...
    nbhd_e, coeffs, nearest_point )
% Visualize current step in algorithm (presence of 
% coeffs and nearest point indicates 3D data)

% show distance neighborhood in full space
figure(1)
not_nbhds_i = ones(1,size(Y,2));
not_nbhds_i ( nbhds_i ) = 0;
not_nbhds_i = find(not_nbhds_i);
plot3(Y(1,not_nbhds_i),Y(2,not_nbhds_i),Y(3,not_nbhds_i),'g.');
hold on
plot3(Y(1,i),Y(2,i),Y(3,i),'bx','MarkerSize',12);
plot3(Y(1,nbhd),Y(2,nbhd),Y(3,nbhd),'bo');
plot3(Y(1,nbhds_i),Y(2,nbhds_i),Y(3,nbhds_i),'r.');
hold off
        
% get local version of nbhds_i
nbhds_i = find( ismember ( nbhd, nbhds_i ) );

% show projection of neighborhood
figure(2)
if nargin < 6
    plot(proj_nbhd(1,:),proj_nbhd(2,:),'bo');
    hold on
    plot(proj_nbhd(1,1),proj_nbhd(2,1),'bx','MarkerSize',12);
    plot(proj_nbhd(1,nbhds_i),proj_nbhd(2,nbhds_i),'r.');
    hold off
else
    plot3(proj_nbhd(1,:),proj_nbhd(2,:),proj_nbhd(3,:),'bo');
    hold on
    plot3(proj_nbhd(1,1),proj_nbhd(2,1),proj_nbhd(3,1),'bx',...
          'MarkerSize',12);
      
    % draw planes
    axis_limits = axis;
    
    % plane 1
    four_points = nbhd_e*[-1 -1; 1 -1; 1 1; -1 1]';
    null_basis = null(repmat(coeffs(1,1:3),3,1));
    point_on_plane = coeffs(1,1:3)\(-coeffs(1,4));
    plane_points = null_basis*four_points+repmat(point_on_plane,1,4);
    fill3(plane_points(1,:),plane_points(2,:),plane_points(3,:),...
        [0 1 1],'FaceAlpha',.5);
    
    % plane 2
    null_basis = null(repmat(coeffs(2,1:3),3,1));
    point_on_plane = coeffs(2,1:3)\(-coeffs(2,4));
    plane_points = null_basis*four_points+repmat(point_on_plane,1,4);
    fill3(plane_points(1,:),plane_points(2,:),plane_points(3,:),...
        [0 1 1],'FaceAlpha',.5);
    
    % draw intersection 
    if nargin == 8
        intersect_vector = cross(coeffs(1,1:3),coeffs(2,1:3))';
        intersect_vector = intersect_vector/norm(intersect_vector);
        points_on_line = [nearest_point - nbhd_e*intersect_vector, ...
                          nearest_point + nbhd_e*intersect_vector];
        plot3(points_on_line(1,:),points_on_line(2,:),...
            points_on_line(3,:),'k-');
    end
    
    % draw 2D neighborhood
    plot3(proj_nbhd(1,nbhds_i),proj_nbhd(2,nbhds_i),...
        proj_nbhd(3,nbhds_i),'r.');
    
    hold off
end

function dist_plane = plane_distance ( X, coeffs )
% Computes the distance to the plane for each point in X

num_X = size(X,2);
dist_plane = abs ( coeffs*[X;ones(1,num_X)] )./ ...
    repmat (sqrt(sum(coeffs(:,1:3).^2,2)),1,num_X);
