function [W, ints, inds] = sample_surface ( X, Z_inds, ...
    min_dist, max_num )
% function [W, ints, inds] = sample_surface ( X, ints, nbhds, ...
%   min_dist, max_num)
% This function provides an "intelligent" sample of X with respect
% to making sure there are adequate samples at self intersections.
%
% INPUTS: X -- original data, points as columns
%         Z_inds -- indices into X of intersection points (obtained
%                   using surface_intersection.m)
%         min_dist -- minimum distance between two points
%         max_num -- maximum number of points in sample
%
% OUTPUTS: W -- sampled data, points as columns
%          ints -- indices into W giving intersection points
%          inds -- indices into original data X giving W
%
% S. Martin
% 12/10/2008

% sample intersections first to guarantee good point placement
intersection_indices = sample_cluster ( X(:,Z_inds), min_dist, max_num );
intersection_indices = Z_inds(intersection_indices);

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% find indices for everything not in the intersection
[m,n] = size(X);
non_ints = ones(1,n);
non_ints(intersection_indices) = 0;
non_ints = find(non_ints);

% count numbers of intersection points, and non intersection points
n_non_ints = length(non_ints);
n_ints = length(intersection_indices);

% next sample remainder of points, while keeping intersection points
% this is a copy of sub_sample.m, slighly modified

% initialization
[m,n] = size(X);  % m is number of dimensions, n is number of points
visit_order = [intersection_indices, non_ints(randperm(s,n_non_ints))];
    % random visit order for points of X, keeping intersection points fixed
X = X(:,visit_order);  % re-arrage points in X in visit order
indices = [(1:n_ints)'; zeros(max_num-n_ints,1)];  % indicies into subsampled points  
min_dist_sq = min_dist^2;  % we calculate squared distance

% cached variables
XX = [sum(X(:,1:n_ints).*X(:,1:n_ints),1),zeros(1,n_non_ints)];  
% XX = sum(X.*X,1) produced incrementally as we subsample

% subsampling
fprintf('     ');
num_found = n_ints;
for i = (n_ints+1):n
  yy = sum(X(:,i).*X(:,i));
  Xy = X(:,indices(1:num_found))'*X(:,i);
  d_square = XX(1:num_found) + yy*ones(1,num_found) - 2*Xy';
  if min(d_square) >= min_dist_sq
      num_found = num_found + 1;
      indices(num_found) = i;
      XX(num_found) = sum(X(:,indices(num_found)).*X(:,indices(num_found)));
      if num_found==max_num
          break
      end
  end
  if ~mod(i,1000)
    fprintf('.');
  end
  if ~mod(i,10000)
    fprintf(' %d\n     ',i);
  end
end
fprintf('\n');

% compute return variables
W = X(:,indices(find(indices)));
ints = 1:n_ints;
inds = visit_order(indices(find(indices)));