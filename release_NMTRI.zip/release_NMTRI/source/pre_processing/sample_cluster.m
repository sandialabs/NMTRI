function indices = sample_cluster (X, min_dist, max_num)
% function indices = sample_cluster(X, min_dist, max_num)
% This function returns a indices of a subsample of X
% with the condition that the subsamples are a minimum
% distance away from each other.
%
% INPUTS: X -- matrix with data points as columns
%         min_dist -- minimum distance between two observations
%         max_num -- maximum number of samples to return
%
% OUTPUT: indices -- indices into columns of X such that
%                    no two points are too close
%
% S. Martin
% 9/12/2008

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% initialization
[m,n] = size(X);  % m is number of dimensions, n is number of points
visit_order = randperm(s,n);  % random visit order for points of X
X = X(:,visit_order);  % re-arrage points in X in visit order
indices = zeros ( max_num, 1 );  % indicies into subsampled points  
min_dist_sq = min_dist^2;  % we calculate squared distance

% cached variables
XX = zeros(1,n);  % XX = sum(X.*X,1) produced incrementally as we subsample

% subsampling
indices(1) = 1;
XX(1) = sum(X(:,indices(1)).*X(:,indices(1)));
num_found = 1;
fprintf('Subsampling\n     ');
for i = 2:n
  yy = sum(X(:,i).*X(:,i));
  Xy = X(:,indices(1:num_found))'*X(:,i);
  d_square = XX(1:num_found) + yy*ones(1,num_found) - 2*Xy';
  if min(d_square) >= min_dist_sq
      num_found = num_found + 1;
      indices(num_found) = i;
      XX(num_found) = sum(X(:,indices(num_found)).*X(:,indices(num_found)));
      if num_found==max_num
          break
      end
  end
  if ~mod(i,1000)
    fprintf('.');
  end
  if ~mod(i,10000)
    fprintf(' %d\n     ',i);
  end
end
fprintf('\n');
indices = visit_order(indices(find(indices)));

return