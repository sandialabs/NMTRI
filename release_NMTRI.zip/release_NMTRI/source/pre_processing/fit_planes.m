function [coeffs, r3, r4, T2, dist_resid, factor_resid] = ...
    fit_planes ( X, rank_tol, call_optimization )
% function [coeffs, r3, r4, T2, dist_resid, factor_resid] = ...
%   fit_planes ( X, rank_tol, call_optimization )
% This code uses constraints as derived by "Solid Analytical Geometry
% and Determinants" by A. Dresden to fit two instersecting planes
% using a quadratic surface (see Chapters 7 & 8).
%
% INPUT: X -- data matrix in 3D, points are columns
%        rank_tol -- tolerance for rank calculations r3 and r4
%        call_optimization -- true to call matlab's optimization
%                             toolbox, false to use initial guess
%
% OUTPUTS: coeffs -- 2x4 matrix with x,y,z,const coefficients = 0
%          r3, r4 -- ranks of matrices a3 and a4 in A. Dresden (should=2)
%          T2 -- sum of determinants (should be < 0 -- see A. Dresden)
%          dist_resid -- mean distance to closest plane
%          factor_resid -- max absolute value of difference
%                          between factored coefficients and
%                          implicit coefficients
%            
% NOTE: No errors are produced, even in the case of complex square
%       roots.  However, errors should be easily discernable
%       by examining the returned metrics.
%
% S. Martin
% 12/3/2008

% call_optimization defaults to true
if nargin < 3
    call_optimization = true;
end

% get xyz coordinates
x = X(1,:)';
y = X(2,:)';
z = X(3,:)';

% form regression matrix for quadratic surface
n = length(x);
M = [x.^2 2*x.*y 2*x.*z 2*x y.^2 2*y.*z 2*y z.^2 2*z ones(n,1)];
A = M'*M;

% get initial guess for optimization (use unconstrained solution)
[u,s,v] = svd(M,0);
a0 = v(:,end);

% transform coefficients to matrix representation
coeff_mat = [a0(1:4)'; ...
             a0(2), a0(5:7)'; ...
             a0([3 6])', a0(8:9)'; ...
             a0([4 7 9])', a0(10)];
[q,lambda] = eigs(coeff_mat);
    
% check if submatrix is rank 2
coeff_mat_2 = q(:,1:2)*lambda(1:2,1:2)*q(:,1:2)';
if rank(coeff_mat_2) == 2
    % this is the best case -- submatrix is already rank 2
    [q,lambda] = eigs(coeff_mat_2(1:3,1:3));
    b = coeff_mat_2(1:3,4);
else
    % otherwise submatrix is rank 1 -- use full coeff_mat
    fprintf('Warning: submatrix not rank 2.\n');
    [q,lambda] = eigs(coeff_mat(1:3,1:3));
    b = coeff_mat(1:3,4);
end

% re-compute according to submatrix
q4 = [lambda(1,1)*q(:,1), lambda(2,2)*q(:,2)]\b;
fro_norm_lambda = lambda(1:2,1:2);
fro_norm_lambda = fro_norm_lambda/sqrt(lambda(1,1)^2+lambda(2,2)^2);
q0 = [q(:,1);q4(1);q(:,2);q4(2);diag(fro_norm_lambda)];

if call_optimization
    
    % call nonlinear constrained optimization routine
    options = optimset('GradObj','on', 'LargeScale', 'off', 'Display', 'off');

    [q,E_val,exit_flag] = fmincon( @quadric_obj_fun, q0, [], [], [], [], [], [], ...
             @quadric_con_fun, options );

else
    
    % no optimization requested -- use initial guess
    q = q0;
    E_val = quadric_obj_fun ( q );
    exit_flag = NaN;
    
end

% check ranks of coefficienct matrix
% (these should be r3 = r4 = 2, T2 <= 0)
coeff_mat = q(1:4)*q(1:4)'*q(9) + q(5:8)*q(5:8)'*q(10);
a = [coeff_mat(:,1);coeff_mat(2:4,2);coeff_mat(3:4,3);coeff_mat(4,4)];
r3 = rank(coeff_mat(1:3,1:3),rank_tol);
r4 = rank(coeff_mat,rank_tol);
T2_part(1) = det(coeff_mat(1:2,1:2));
T2_part(2) = det(coeff_mat([1 3],[1 3]));
T2_part(3) = det(coeff_mat(2:3,2:3));
T2 = sum(T2_part);
 
% factor polynomial according to formulas in A. Dresden, pg. 207
[min_T2_part, min_T2_ind] = min(T2_part);
switch min_T2_ind
    
    case 1
        % in case 1, we know that a12^2 - a11*a22 >= 0
        % (this is the case in A. Dresden, pg. 207)
        lambda = (a(2) + sqrt(-T2_part(1)))/a(1);
        mu = (a(2) - sqrt(-T2_part(1)))/a(1);
        coeffs(1,:) = 2*coeff_mat(2,:) - 2*lambda*coeff_mat(1,:);
        coeffs(2,:) = 2*coeff_mat(2,:) - 2*mu*coeff_mat(1,:);
        
    case 2
        % in case 2, we know that a13^2 - a11*a33 >= 0
        lambda = (a(3) + sqrt(-T2_part(2)))/a(1);
        mu = (a(3) - sqrt(-T2_part(2)))/a(1);
        coeffs(1,:) = 2*coeff_mat(3,:) - 2*lambda*coeff_mat(1,:);
        coeffs(2,:) = 2*coeff_mat(3,:) - 2*mu*coeff_mat(1,:);
        
    case 3
        % in case 3, we know that a23^2 - a22*a33 >= 0
        lambda = (a(6) + sqrt(-T2_part(3)))/a(5);
        mu = (a(6) - sqrt(-T2_part(3)))/a(5);
        coeffs(1,:) = 2*coeff_mat(3,:) - 2*lambda*coeff_mat(2,:);
        coeffs(2,:) = 2*coeff_mat(3,:) - 2*mu*coeff_mat(2,:);
        
end

% compute dist residual
dist_both_planes = abs (coeffs*[X;ones(1,n)] )./ ...
    repmat (sqrt(sum(coeffs(:,1:3).^2,2)),1,n);
dist_resid = mean(min(dist_both_planes,[],1));

% compute factorization residual
factor_resids = ...
    [a(1) - coeffs(1,1)*coeffs(2,1); ...
     2*a(2) - coeffs(1,1)*coeffs(2,2) - coeffs(2,1)*coeffs(1,2); ...
     2*a(3) - coeffs(1,1)*coeffs(2,3) - coeffs(2,1)*coeffs(1,3); ...
     2*a(4) - coeffs(1,1)*coeffs(2,4) - coeffs(2,1)*coeffs(1,4); ...
     a(5) - coeffs(1,2)*coeffs(2,2); ...
     2*a(6) - coeffs(1,2)*coeffs(2,3) - coeffs(2,2)*coeffs(1,3); ...
     2*a(7) - coeffs(1,2)*coeffs(2,4) - coeffs(2,2)*coeffs(1,4); ...
     a(8) - coeffs(1,3)*coeffs(2,3); ...
     2*a(9) - coeffs(1,3)*coeffs(2,4) - coeffs(2,3)*coeffs(1,4); ...
     a(10) - coeffs(1,4)*coeffs(2,4)];
factor_resid = max(abs(factor_resids));

% nested functions for optimization

% objective function for fmincon (sum of squares of quadric poly)
function [E,grad_E] = quadric_obj_fun ( q )
    coeff_mat = q(1:4)*q(1:4)'*q(9) + q(5:8)*q(5:8)'*q(10);
    a = [coeff_mat(:,1);coeff_mat(2:4,2);coeff_mat(3:4,3);coeff_mat(4,4)];
    E = a'*A*a;
    if nargout == 2
        % compute gradient
        J(1:4,1) = [2*q(1);q(2:4)]*q(9);
        J([2,5:7],2) = [q(1);2*q(2);q(3:4)]*q(9);
        J([3 6 8 9],3) = [q(1:2);2*q(3);q(4)]*q(9);
        J([4 7 9 10],4) = [q(1:3);2*q(4)]*q(9);
        J(1:4,5) = [2*q(5);q(6:8)]*q(10);
        J([2,5:7],6) = [q(5);2*q(6);q(7:8)]*q(10);
        J([3 6 8 9],7) = [q(5:6);2*q(7);q(8)]*q(10);
        J([4 7 9 10],8) = [q(5:7);2*q(8)]*q(10);
        J(:,9) = [q(1)*q(1:4); q(2)*q(2:4); q(3)*q(3:4); q(4)^2];
        J(:,10) = [q(5)*q(5:8); q(6)*q(6:8); q(7)*q(7:8); q(8)^2];
        grad_E = 2*a'*A*J;
    end
end

% constraint function for fmincon (rank deficient coeff matrices)
function [c,ceq] = quadric_con_fun ( q )
    coeff_mat = q(1:4)*q(1:4)'*q(9) + q(5:8)*q(5:8)'*q(10);
    c = det(coeff_mat(1:2,1:2)) + det(coeff_mat([1 3],[1 3])) + ...
        det(coeff_mat(2:3,2:3));
    ceq(1) = q(1:3)'*q(5:7);
    ceq(2) = q(1:3)'*q(1:3) - 1;
    ceq(3) = q(5:7)'*q(5:7) - 1;
    ceq(4) = q(9)^2 + q(10)^2 - 1;
end

return

% print report (for debugging)
fprintf('--------------------------\n');
fprintf('Difference ||a-a0||: %f\n',norm(a-a0));
fprintf('E_val = %f, exitflag = %d\n',E_val, exit_flag);
fprintf('r3 = %d, r4 = %d, T2 = %f\n',r3,r4,T2);
fprintf('Factored using case %d, with T2 = %f\n',min_T2_ind, ...
    T2_part(min_T2_ind));
fprintf('Distance Residual = %f\n',dist_resid);
fprintf('Factorization Residual = %f\n',factor_resid);

end