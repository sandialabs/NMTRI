function W_nbhds = restrict_nbhds ( inds, nbhds )
% function W_nbhds = restrict_nbhds ( W_inds, nbhds )
% This function restricts the neighborhoods from a larger set (X)
% to a smaller set (W).
%
% INPUTS: W_inds -- indices of W into larger set X
%         nbhds -- neighborhoods indices in larger set X
%                  (neighborhoods are in W)
%
% OUTPUTS: W_nbhds -- nbhds in terms of indices into W
%
% S. Martin
% 3/24/2009

% restrict nbhds to W
fprintf('Restricting neighborhoods ...\n');
num_W = length(inds);
for j = 1:num_W
    nbhd_j_in_X = intersect(nbhds{j},inds); % indices into X
    W_nbhds{j} = find(ismember(inds,nbhd_j_in_X)); % indices into W
end