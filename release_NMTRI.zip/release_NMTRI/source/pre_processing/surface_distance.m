function D = surface_distance ( X, nbhds )
% function D = sparse_distance ( X, nbhds )
% This function produces sparse distance matrices using
% Euclidean distance.
%
% INPUTS: X -- a d x N data matrix with points as columns
%         nbhds -- cell array with neighborhoods of each point in X
%                  (as returned by surface_nbhds)
%
% OUTPUT: D -- pairwise sparse NxN distance matrix
%
% NOTES: 
% 1. D is produced such that D(i,i)=0 for all i, and
%    D(nbhd_i,nbhd_i) is a full matrix.    
%
% S. Martin
% 12/10/2008

% compute memory needed for distance matrix in [i,j,val] format 
N = size(X,2);
num_non_zeros = 0;
for i = 1:N
    num_nbhd = length(nbhds{i});
    num_non_zeros = num_non_zeros + num_nbhd*(num_nbhd-1)/2;
end
D_full = zeros(num_non_zeros,3);

fprintf('Computing sparse Euclidean distance matrix ...\n     ');
D_pos = 1;
for i = 1:N
    
    % compute neighborhood distances
    nbhd_D = L2_distance ( X(:,nbhds{i}), X(:,nbhds{i}), 1 );
    nbhd_D = triu(nbhd_D);
    
    % compute sparse matrix values
    num_nbhd = length(nbhds{i});
    sparse_inds = [repmat(nbhds{i}',num_nbhd,1),...
        reshape(repmat(nbhds{i},num_nbhd,1),num_nbhd*num_nbhd,1)];
    sparse_inds = sort(sparse_inds,2);
    sparse_D = [sparse_inds,...
        reshape(nbhd_D,num_nbhd*num_nbhd,1)];
    sparse_D = sparse_D(find(sparse_D(:,3)~=0),:);

    % record values in [i,j,val] format
    D_full(D_pos:(D_pos+num_nbhd*(num_nbhd-1)/2-1),:) = sparse_D;
    D_pos = D_pos+num_nbhd*(num_nbhd-1)/2;
    
    % output progress
    if mod(i,100)==0
        fprintf('.');
    end
    if mod(i,1000)==0
        fprintf(' %d\n     ',i);
    end
    
end
fprintf('\n');

% show number of neighbors per point
for i = 1:N
    ns(i) = length(nbhds{i});
end
fprintf('Minimum neighorhood size: %d\n',min(ns));
fprintf('Average neighborhood size: %f\n',mean(ns));
fprintf('Maximum neighborhood size: %d\n',max(ns));

% convert to sparse matrix
fprintf('Converting to sparse matrix ...\n');
[unique_rows,unique_inds] = unique(uint32(D_full(:,1:2)),'rows');
D = spconvert(D_full(unique_inds,:));
D(N,N) = 0;
D = D+D';

return

% check results -- for debugging
fprintf('Checking results ...\n     ');
for i = 1:N
    
    % compute neighborhood distances
    nbhd_D = L2_distance ( X(:,nbhds{i}), X(:,nbhds{i}), 1 );
    
    if sum(sum(abs(nbhd_D-D(nbhds{i},nbhds{i}))))>10^-8
        error ('Invalid neighborhood detected.');
    end

    % output progress
    if mod(i,100)==0
        fprintf('.');
    end
    if mod(i,1000)==0
        fprintf(' %d\n     ',i);
    end
    
end
fprintf('\n');
    