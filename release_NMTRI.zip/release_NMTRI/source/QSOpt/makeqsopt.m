filename='mexqsopt.c';

XPpath='c:\work\solvers\qsopt';

include=[XPpath];
lib=[XPpath];

library=[lib '\qsopt.lib'];

cmd=[' -I' include ' ' filename ' ' library]
eval(['mex ' cmd]);
