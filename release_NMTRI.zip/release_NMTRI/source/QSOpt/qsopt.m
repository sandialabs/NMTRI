function [x,lambda,status] = qsopt(c,A,b,Aeq,beq,lb,ub,options)
% QSOPT Interface to QSopt
%
% [x,z,status] = qsopt(c,A,b,Aeq,beq,lb,ub,options)
%
% min c'*x
% s.t   A*x <  b, Aeq*x == beq, lb < x < ub
%
% Options structure (see qsopt user manual for details)
%    options.dual         [0|1 (default 0)]. Use dual simplex algorithm instead of primal
%    options.primalprice  [1|2|3|4 (default 1)] 
%    options.dualprice    [6|7|8|9 (default 6)] 
%    options.scale        [0|1 (default 1)] 
%    options.maxiter      [integer>0 (default 300000)]
%    options.maxtime      [real>0 (default 10000)]
%
% output
%  x      : primal
%  z      : dual
%  status : 1 - optimal, 2 - infeasible, 3- unbounded, 4 - iteration limit,
%           5 - time limit, 6 - other problem

% Author Johan L�fberg ETH Z�rich.
% $Id: qsopt.m,v 1.10 2004/07/13 09:45:56 johanl Exp $

% **************************
% Check input
% **************************
if nargin<8
    options.dual = 1;
    options.primalprice = 1;
    options.dualprice = 6;
    options.scale = 1;
    options.maxiter = 300000;
    options.maxtime = 10000;
    if nargin < 7
        ub = [];
        if nargin < 6
           lb = [];
            if nargin < 5
                beq = [];
                if nargin < 4
                    Aeq = [];
                    if nargin < 3
                        b = [];
                        if nargin < 2
                            A = [];
                            if nargin < 1
                                help qsopt;return
                            end
                        end
                    end
                end
            end
        end
    end
end

if isempty(c)
    c = repmat(1,size(A,2),1);
end

% **************************
% Merge constraints
% **************************
A = [Aeq;A];
b = [beq;b];


% **************************
% Avoid empty problem (?)
% **************************
if isempty(b);
    A = c';
    b = 1e6;
end

% **************************
% QSOPT sparse format
% **************************
cmatcnt = sum(A ~= 0,1);
cmatbeg = cumsum([0 cmatcnt]);cmatbeg = cmatbeg(1:end-1);
nzA = find(A);
cmatind = rem(nzA-1,size(A,1))';
cmatval = A(nzA);

% **************************
% CALL MEX FILE
% **************************
try
    [x,lambda,status] = mexqsopt(full(cmatcnt(:)'),full(cmatbeg(:)'),full(cmatind(:)'),full(cmatval(:)'),full(c(:)'),full(b(:)'),length(beq),full(lb(:)'),full(ub(:)'),options);
catch
    x
end

