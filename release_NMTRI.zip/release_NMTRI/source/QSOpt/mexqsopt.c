#include "mex.h"
#include "qsopt.h"

/*
 
 Disclaimer : Almost no error checks (relies on checks in qsopt.m). Horrible C-code (I'm a MATLAB coder....)
 TODO       : Input check, error check, memory deallocation?, options
 Author     : Johan L�fberg, ETH Z�rich, loefberg@control.ee.ethz.ch
 
 */

void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
    QSprob p;
    
    int *cmatind,*cmatbeg,*cmatcnt;
    double *cmatind_in,*cmatbeg_in,*cmatcnt_in,*cmatval;
    double *obj,*rhs,*lower,*upper;
    char *sense;
    
    double *x,*lambda;
    double *returncode;
    
    mxArray *afield;    
    double *neq;
    char errmsg[1024];
    int ops_dual;
     
    int upper_alloc,lower_alloc,ncols,nrows,status,isize, rval,num_indicies,i;
    
    if(nrhs < 9) mexErrMsgTxt("9 inputs required in call to mexqsopt. Bug in qsopt.m?...");

    /* Get pointers to input */
    cmatcnt_in = mxGetPr(prhs[0]);
    cmatbeg_in = mxGetPr(prhs[1]);
    cmatind_in = mxGetPr(prhs[2]);
    cmatval    = mxGetPr(prhs[3]);
    obj        = mxGetPr(prhs[4]);
    rhs        = mxGetPr(prhs[5]);
    neq        = mxGetPr(prhs[6]);
    lower      = mxGetPr(prhs[7]);
    upper      = mxGetPr(prhs[8]);
    
    ncols = mxGetN(prhs[4]); /* Length of c*/
    nrows = mxGetN(prhs[5]); /* length of b*/
           
    /* Copy data for first integer argument
       This is probably utterly stupid code...*/
    isize = mxGetN(prhs[0]);
    cmatcnt  =(int *) mxCalloc(isize, sizeof (int));
    for (i = 0; i < isize ; i++){
        cmatcnt[i] = (int) cmatcnt_in[i];
    }
    /* Copy data for second integer argument */
    isize = mxGetN(prhs[1]);
    cmatbeg  =(int *) mxCalloc(isize, sizeof (int));
    for (i = 0; i < isize ; i++){
        cmatbeg[i] = (int) cmatbeg_in[i];
    }
    /* Copy data for third integer argument */
    isize = mxGetN(prhs[2]);
    cmatind  =(int *) mxCalloc(isize, sizeof (int));
    for (i = 0; i < isize ; i++){
        cmatind[i] = (int) cmatind_in[i];
    }
   
    /* Create sense vector */
    sense = (char *) mxCalloc(nrows, sizeof (char));
    isize = (int) *neq;
    for (i = 0; i < isize; i++){
        sense[i] = (char) 'E';
    }
    for (i = isize; i < nrows; i++){
        sense[i] = (char) 'L';
    }
      
    /* Create lower bounds if not available */
    lower_alloc = 0;
    isize = mxGetN(prhs[7]);
    if (isize==0){
        lower  = (double *) mxCalloc(ncols, sizeof (double));
        for (i = 0; i < ncols; i++){
            lower[i] = -QS_MAXDOUBLE;
        }
        lower_alloc = 1;
    }    
    /* Create upper bounds if not available*/
    upper_alloc = 0;
    isize = mxGetN(prhs[8]);
    if (isize==0){
        upper  = (double *) mxCalloc(ncols, sizeof (double));
        for (i = 0; i < ncols; i++){
            upper[i] = QS_MAXDOUBLE;
        }
        upper_alloc = 1;
    }
         
    /* Allocate for return data*/
    plhs[0] = mxCreateDoubleMatrix(ncols,1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nrows,1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(1,1, mxREAL);
    x      = mxGetPr(plhs[0]);
    lambda = mxGetPr(plhs[1]);
    returncode = mxGetPr(plhs[2]);
        
    /* Create problem instance */
    p = QSload_prob ("yalmip", ncols, nrows, cmatcnt, cmatbeg, cmatind, cmatval,QS_MIN, obj, rhs, sense, lower, upper,NULL,NULL);
  
    /* OPTIONS */   
    afield = mxGetField( prhs[9],0,"dualprice");
    if (afield != NULL){           
        QSset_param(p,QS_PARAM_DUAL_PRICING,(int) *(mxGetPr(afield)));   
    }    
    afield = mxGetField( prhs[9],0,"primalprice");
    if (afield != NULL){
        QSset_param(p,QS_PARAM_PRIMAL_PRICING, (int) *(mxGetPr(afield)));  
    }                 
    afield = mxGetField( prhs[9],0,"scale");
    if (afield != NULL){
        QSset_param(p,QS_PARAM_SIMPLEX_SCALING,(int) *(mxGetPr(afield)));           
    }    
    afield = mxGetField( prhs[9],0,"maxiter"); /* FIX : Does not work? */
    if (afield != NULL){                 
        QSset_param(p,QS_PARAM_SIMPLEX_MAX_ITERATIONS, (int) *(mxGetPr(afield)));   
    }  
    afield = mxGetField( prhs[9],0,"maxtime"); /* FIX : Does not work? */
    if (afield != NULL){                 
        QSset_param(p,QS_PARAM_SIMPLEX_MAX_TIME,*(mxGetPr(afield)));       
    }          
    
    afield = mxGetField( prhs[9],0,"dual");
    if (afield != NULL){
        ops_dual = (int) *(mxGetPr(afield));
    }
    else{
        ops_dual = 0;
    }
      
    switch (ops_dual) {
        case 0:
            rval = QSopt_primal (p, &status);
            break;
        default:
            rval = QSopt_dual (p, &status);
    }
    if (rval){
        /* Do something? */
    }
    else{
        /* If we started solver, get solution)*/
        if (status!=6){ 
            QSget_solution(p, NULL, x, lambda,NULL,NULL);       
        }
    }
        
    *returncode = (double) status;
    if(p != NULL) QSfree_prob(p);
    if(cmatind != NULL) mxFree(cmatind);
    if(cmatbeg != NULL) mxFree(cmatbeg);
    if(cmatcnt != NULL) mxFree(cmatcnt);
    if(upper != NULL && upper_alloc==1) mxFree(upper);
    if(lower != NULL && lower_alloc==1) mxFree(lower);
}




