INSTALLATION AND COMPILATION INSTRUCTIONS:

To compile your own version, you need to download suitable library and header file from the the QSopt homepage 

http://www.isye.gatech.edu/~wcook/qsopt/downloads/downloads.htm

As an example, the following MATLAB command was used to generate the attached .dll file (using qsopt.lib library for Windows 98/ME/NT/2000/XP, Microsoft Visual C/C++ version 6.0, MATLAB 7.0)

mex -Ic:\solvers\qsopt mexqsopt.c c:\solvers\qsopt\qsopt.lib

Questions and comments can be sent to loefberg@control.ee.ethz.ch


