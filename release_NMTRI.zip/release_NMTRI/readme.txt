Non-manifold Surface Triangulation
----------------------------------

S. Martin
5/12/2010

License
-------
Copyright 2009 Sandia Corporation. Under the terms of Contract
DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
certain rights in this software.

NOTICE:
For five (5) years from 08/06/2010, the United States Government is granted for itself and others acting on its behalf a paid-up, nonexclusive, irrevocable worldwide license in this data to reproduce, prepare derivative works, and perform publicly and display publicly, by or on behalf of the Government. There is provision for the possible extension of the term of this license. Subsequent to that period or any extension granted, the United States Government is granted for itself and others acting on its behalf a paid-up, nonexclusive, irrevocable worldwide license in this data to reproduce, prepare derivative works, distribute copies to the public, perform publicly and siplay publicly, and to permit others to do so. The specific term of the license can be identified by inquiry made to Sandia Corportation or DOE.
 
NEITHER THE UNITED STATES GOVERNMENT, NOR THE UNITED STATES DEPARTMENT OF ENERGY, NOR SANDIA CORPORATION, NOR ANY OF THEIR EMPLOYEES, MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LEGAL RESPONSIBILITY FOR THE ACCURACY, COMPLETENESS, OR USEFULNESS OF ANY INFORMATION, APPARATUS, PRODUCT, OR PROCESS DISCLOSED, OR REPRESENTS THAT ITS USE WOULD NOT INFRINGE PRIVATELY OWNED RIGHTS.
 
Any licensee of this software has the obligation and responsibility to abide by the applicable export control laws, regulations, and general prohibitions relating to the export of technical data. Failure to obtain an export control license or other authority from the Government may result in criminal liability under U.S. laws.

Citation
--------
If you use this code, please cite the paper:

S. Martin, J.-P. Watson (2011), "Non-Manifold Surface Reconstruction from High Dimensional Point Cloud Data," Computational
Geometry: Theory and Applications 44(8):427-441.

If you use the cylcooctane dataset, you might also want to cite:

W. M. Brown, S. Martin, S. N. Pollock, E. A. Coutsias, and J.-P. Watson, "Algorithmic Dimensionality Reduction for Molecular
Structure Analysis," Journal Chemical Physics 129(6):064118

S. Martin, A. Thompson, E. A. Coutsias and J.-P. Watson, "Topology of Cyclooctane Energy Landscape," Journal
Chemical Physics 132:234115.

Installation
------------

This code requires a linear programming solver.  If you have the matlab optimization toolbox the code will run as is.
If you don't have the matlab optimization toolbox, you can use QSOpt.  QSOpt can be obtained from
http://www2.isye.gatech.edu/~wcook/qsopt/.  You must also install the matlab mex interface to QSOpt in the QSOpt directory
of the source folder.  This is included but was written by J. Lofberg and was originally downloaded from
http://control.ee.ethz.ch/~joloef/mexqsopt.msql.  In addition there are many other linear programming routines available on
the internet.  After you have installed QSOpt, you have to uncomment the appropriate line in the intersect_simplex.m routine.

Once you have installed a linear programming routine, you can add the non-manifold surface triangulation code to your
matlab path by typing

>> install_non_manifold_triangulation;

General Description
-------------------

As described in the paper, there are two parts to this code: pre-processing and reconstruction.  These two parts are
formally separated in the source directory using the folders "pre_processing" and "nonmanifold_surface".  The point
of the pre-processing routines, many of which are redundant (see note 1), is to obtain neighborhoods and distances
such that the triangulation routines will be successfull.  Often you will have to experiment with the various parameters (as
described in the paper) in order to get satisfactory neighborhoods.

Notes & Tips
------------

1.  This code is not well optimized for speed.  There are many redundant calculations, and possible issues with
    memory management.  If problem size becomes an issue try downsampling.  If that doesn't work you may have to use
    geodesic distances (not included).  If you do want to code geodesic distances I recommend using the Matlab
    Boost Graph Library, available from the Mathworks File Exchange by David Gleich.

2.  If the program terminates without an error, chances are good that the triangulations is correct.
    You should still check for errors, especially if your neighborhoods have relatively few points.

3.  If the program terminates with an error, try to vary the parameters so that it completes correctly.
    The best parameter to try first is neighborhood size.  Failing that, it sometimes help if you can
    re-sample your data at a higher resolution (not alway possible, depending on the dataset).

4.  Manifolds with boundary do not work very well, mainly due to thin triangles which tend to develop
    near the boundary.  There are a at least two things you can try: (a) If you can characterize the boundary points
    then you can treat it as an intersection and use the code as if the boundary were an intersection curve 
    (see Mobius strip as an example), (b) try setting include_neighbors to false in triangulate_surface.m.

5.  There are a lot of visualizations to help discover the appropriate parameters.  In particular almost every routine
    has a make_plots option which helps you see what is going on with the various algorithms.  In addition,
    when any routine crashes it produces visualizations hopefully showing what went wrong.

6.  Do not be afraid to "cheat."  If you know where the intersections should be or can characterize the
    neighborhoods then by all means do so.  Pre-processing is the key to success, and fitting the two planes
    is a difficult problem.  Intersections can be specified in the same way that boundaries are specified, as in
    the Mobius strip and Henneberg surface examples.

Usage
-----

Here we show how the examples in the paper were generated.

Sphere:
>> X = generate_sphere ( 10000, .1 );
>> nbhds = surface_nbhds ( X, 1:886, [], .4, 2*ones(1,886), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, [], nbhds );

Torus:
>> X = generate_torus ( 10000, .3 );
>> nbhds = surface_nbhds ( X, 1:667, [], 1, 2*ones(1,667), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, [], nbhds );

Double-Torus:
>> X = generate_double_torus ( 10000, .3 );
>> nbhds = surface_nbhds ( X, 1:813, [], 1.2, 2*ones(1,813), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, [], nbhds );

Mobius Strip:
>> [X,m_ints] = generate_mobius (10000,.1);
>> nbhds = surface_nbhds ( X, 1:416, m_ints, .4, 2*ones(1,416), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, m_ints, nbhds, 0 );

Klein Figure 8 (a=3):
>> X = generate_klein_f8 ( 10000, .25 );
>> nbhds = surface_nbhds ( X, 1:1940, [], 1, 2*ones(1,1940), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, [], nbhds );

Real Projective Plane:
>> X = generate_RP2 ( 100000, .1 );
>> nbhds = surface_nbhds ( X, 1:753, [], .35, 2*ones(1,753), 0, 0 );
>> D = surface_distance ( X, nbhds );
>> K = triangulate_surface ( X, D, [], nbhds );

Sphere Intersecting Sphere (saved in sphere_sphere.mat):
>> X = generate_sphere_sphere (100000, .01);
>> ints = surface_intersection ( X, .25, .05, .05, .025, .025, 10^-8 );
>> [W, W_ints, inds] = sample_surface ( X, ints, .1, 83646 );
>> nbhds = surface_nbhds ( X, inds, inds(W_ints), .25, .05, .05, 10^-8 );
>> W_nbhds = restrict_nbhds ( inds, nbhds );
>> D = surface_distance ( W, W_nbhds );
>> K = triangulate_surface ( W, D, W_ints, W_nbhds );

Sphere Intersecting Torus (saved in sphere_torus.mat):
>> X = generate_sphere_torus (100000, .01);
>> ints = surface_intersection ( X, .25, .05, .05, .025, .025, 10^-8 );
>> [W, W_ints, inds] = sample_surface ( X, ints, .075, 152609 );
>> W_nbhds = surface_nbhds ( W, 1:13059, W_ints, .25, .05, .05, 10^-8 );
>> D = surface_distance ( W, W_nbhds );
>> K = triangulate_surface ( W, D, W_ints, W_nbhds );

Klein Figure 8 Immersion (saved in klein_f8_imm.mat):
>> X = generate_klein_f8_imm ( 100000, .025 );
>> ints = surface_intersection ( X, .2, .075, .05, .05, .025, 10^-8 );
>> [W, W_ints, inds] = sample_surface ( X, ints, .15, 61440 );
>> nbhd_dim = compute_nbhd_dim ( X, inds, ints, .4 );
>> nbhds = surface_nbhds ( X, inds, inds(W_ints), .4, nbhd_dim, .05, 10^-8 );
>> W_nbhds = restrict_nbhds ( inds, nbhds );
>> D = surface_distance ( W, W_nbhds );
>> K = triangulate_surface ( W, D, W_ints, W_nbhds );

Henneberg Surface:
>> [X,P] = generate_henneberg ( 100000, .25 );
>> ints = surface_intersection ( X, 4, .05, 1, .25, .25, 10^-8 );
>> [W, W_ints, inds] = sample_surface ( X, ints, .75, 13637 );
>> nbhds = surface_nbhds ( X, inds, inds(W_ints), 4, .05, 1,10^-8 );
>> W_nbhds = restrict_nbhds ( inds, nbhds );
>> [B,boundary,b_nbhds] = henneberg_boundary ( W_nbhds, W_ints, ...
       X(:,inds), P(:,inds), [.05,.15], [.075,.25], 2.5 );
>> D = surface_distance ( B, b_nbhds );
>> K = triangulate_surface ( B, D, [W_ints, boundary], b_nbhds );
