function install_non_manifold_triangulation ()
% This is a function which adds the source folders to the matlab path.

% get current path
curr_path = pwd;

% add pre-processing code
pre_pro = [curr_path,'/source/pre_processing'];
addpath (pre_pro);

% add nonmanifold surface triangulation
nm_surf = [curr_path,'/source/nonmanifold_surface'];
addpath (nm_surf);

% add matlab QSOpt library
mat_QSOpt = [curr_path,'/source/QSOpt'];
addpath (mat_QSOpt);