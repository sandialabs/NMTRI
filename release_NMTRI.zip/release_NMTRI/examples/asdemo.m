% ASDEMO	a demo script for ASHAPE / ASLIB
%
% SYNTAX
%		ASDEMO
% EXAMPLE
%		asdemo
% NOTE
%		ASDEMO sets your random generator!

%%

% created:
%	us	17-Jan-2005
% modified:
%	us	24-Apr-2007 20:41:12
%%

%% create some data

% fill a square with random data
% ... and put some holes into it
% note
% - sets and uses Marsaglia's algorithm 

		n=400;
		rand('state',10);
		x=rand(n,1);
		y=rand(n,1);
		cp=[
			.25	.25	.1
			.75	.25	.2
			.25	.75	.1
			.75	.75	.4
			.5	.5	.1
		];
		a=pi/180*(0:360);
	for	j=1:size(cp,1)
		z=cp(j,1)+1i*cp(j,2)+cp(j,3)*exp(1i*a);
		z=inpolygon(x,y,real(z),imag(z));
		x=x(~z);
		y=y(~z);
	end
		dp=get(0,'defaultfigurepaperorientation');
		dc=get(0,'defaultfigurecolor');
		set(0,'defaultfigurepaperorientation','portrait');
		set(0,'defaultfigurecolor',[1 1 1]);
%%

%% create ALPHA SHAPES (1)

% create ALPHA SHAPES using circles with radius r
% show all valid ALPHA CIRCLES using option [-bc]
% for available options see: ALSIB -o
% note
% - ALPHA LINE ALPHA CIRCLES are darker

		r=.09;
		disp('alpha shaping in progress...');
		p=ashape(x,y,r,'-bc');
		disp('alpha shaping done');
		disp(sprintf('runtime%10.3fs',p.runtime));
		disp('press any key to continue...');
		pause;
%%

%% modify the plot using ASLIB subroutines

% create a new figure and turn ALPHA CIRCLES off
% ... using a function handle to ASLIB's graphics engine
% for available subroutines see: ASLIB -s

		figure;
% ... plot all elements
		p=p.f.gall(p);
% ... remove ALPHA CIRCLES
		p=p.f.gcir(p,1);
% ... change DATA MARKERS to (+);
		set([p.h.AS_dat{:}],'marker','+');

% mark ALPHA LINE nodes and edges
% ... using index fields returned in P
% for an explanation of P fields see: ASLIB -f

		ix=p.dmod==4;
		line(p.x(ix),p.y(ix),...
			'marker','o',...
			'markersize',8,...
			'markerfacecolor',[.5 .5 0],...
			'linestyle','none',...
			'color',[0 0 0]);
		ix=p.amod==2;
		line(p.x(p.seg(ix,:)).',p.y(p.seg(ix,:)).',...
			'linewidth',4,...
			'color',[0 0 0]);
		disp('press any key to continue...');
		pause;
%%

%% create ALPHA SHAPES (2)

% use a different ALPHA CIRCLE radius, do not plot at runtime [-g]

		o=ashape(p.x,p.y,r/2,'-g');
% ... create an alias for later plotting
		f=o.f.gpat;
%%

%% show ALPHA PATCHES

% note
% - CONVEX HULLS  are shown in light red
% - ALPHA LINES   are shown in bold black
% - ALPHA SHAPES  are grouped by the color of their ALPHA NODES (squares)
% - ALPHA PATCHES are marked  by the color of their area

		figure;
		f(o);
		disp('press any key to continue...');
		pause;
%%

%% mark ALPHA SHAPES / ALPHA PATCHES

% individual ALPHA SHAPES/ALPHA PATCHES are marked in cyan
% by selecting
% - ALPHAP PATCHES | ALPHA HULLS on the graph
% - SHAPE | PATCH elements on the colorbar
% selections are toggled
% here we selected
% - ALPHA SHAPE #2
% - ALPHA PATCH #3 of ALPHA SHAPE #1

		figure;
		f(o);
		disp('mark SHAPES / PATCHES');
		disp('press any key to continue...');
		pause;
		set(0,'defaultfigurepaperorientation',dp);
		set(0,'defaultfigurecolor',dc);
%%
