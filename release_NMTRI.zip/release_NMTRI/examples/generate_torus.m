function X = generate_torus ( n, r )
% function X = generate_torus ( n, r );
% This function generates n points uniformly subsampled from a torus 
% of tube radius 1 and hole radius 2.
%
% INPUT: n -- number of points on placed randomly on torus.
%        r -- radius to use for uniform subsampling
%
% OUTPUT: X -- points (as columns) on torus in 3D
%
% NOTE: Actual number of returned points will be less than n
%       depending on the value of r.
%
% S. Martin
% 6/9/2008

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

r_hole = 2;  % radius to inside of hole
r_tube = 1;  % radius of tube

% generate random points on manifold
uu = 2*pi*rand(s,1,n);  vv = 2*pi*rand(s,1,n);
X = [(r_hole+r_tube*cos(vv)).*cos(uu); (r_hole+r_tube*cos(vv)).*sin(uu); r_tube*sin(vv)];

% sample uniformly from manifold
inds = sample_cluster ( X, r, n );
%inds = px_maxmin ( X, 'vector', r, 'n' );
X = X(:,inds);
P = [uu(inds);vv(inds)];