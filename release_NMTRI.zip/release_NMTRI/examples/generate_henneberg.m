function [X,P] = generate_henneberg ( n, r_input )
% function [X,P] = generate_henneberg ( n, r, nbhd_e )
% This function generates random data for the Henneberg surface.
%
% INPUTS: n -- number of points on sphere
%         r -- minimum distance to use for uniform sampling
%
% OUTPUTS: X -- Henneberg's minimal surface in 3d (x,y,z) coordinates
%          P -- Henneberg parameters (first row r, second row phi)
%
% S. Martin
% 3/12/2009

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

r = rand(s,1,n)*.2 + .4;
phi = rand(s,1,n)*2*pi;

X = henneberg ( r, phi );

% sample uniformly from set
inds = sample_cluster ( X, r_input, n );
X = X(:,inds);
P = [r(inds);phi(inds)];

function H = henneberg ( r, phi )

x = 2*(r.^2 - 1).*cos(phi)./r - 2*(r.^6-1).*cos(3*phi)./(3*r.^3);
y = -(6*r.^2.*(r.^2-1).*sin(phi) + 2*(r.^6-1).*sin(3*phi))./(3*r.^3);
z = 2*(r.^4+1).*cos(2*phi)./(r.^2);

H = [x;y;z];
