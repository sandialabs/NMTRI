function X = generate_RP2 ( n, r );
% function X = generate_RP2 ( n, r );
% This function generates random data for an embedding of
% the real projective plane.
%
% INPUTS: n -- number of points on sphere
%         r -- radius to use for uniform sampling
%
% OUTPUTS: X -- RP2 embedding in 4d (x,y,z,w) coordinates
%
% S. Martin
% 7/16/2008

% 1. generate points on a sphere

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z direction angle
rho = rand(s,1,n)*pi;

% find x,y,z using spherical transforms
x = cos(theta).*sin(rho);
y = sin(theta).*sin(rho);
z = cos(rho);

% 2. map those points to the real projective plane

X = [x.*y; x.*z; y.*z; x.^2; y.^2; z.^2];

% 3. sample uniformly from manifold
inds = sample_cluster ( X, r, n );
X = X(:,inds);
P = [theta(inds);rho(inds)];