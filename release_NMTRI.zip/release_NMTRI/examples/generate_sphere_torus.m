function X = generate_sphere_torus ( n, r )
% function X = generate_sphere_torus ( n, r );
% This function generates random data for a sphere intersecting
% a torus.
%
% INPUTS: n -- number of points on sphere & torus (each)
%         r -- minimum distance to use for uniform sampling
%
% OUTPUTS: X -- sphere/torus in 3d (x,y,z) coordinates
%
% S. Martin
% 3/24/2009

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% first generate sphere

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z direction angle
rho = rand(s,1,n)*pi;

rad_sphere = 2;

% find x,y,z using spherical transforms
x = rad_sphere*cos(theta).*sin(rho);
y = rad_sphere*sin(theta).*sin(rho);
z = rad_sphere*cos(rho);
X_sphere = [x;y;z];

% second generate torus

r_hole = 2;  % radius to inside of hole
r_tube = 1;  % radius of tube
displacement = 2 + sqrt(5);  % displacement of torus relative to origin

% generate random points on manifold
uu = 2*pi*rand(s,1,n);  vv = 2*pi*rand(s,1,n);
X_torus = [(r_hole+r_tube*cos(vv)).*cos(uu) + displacement; ...
    (r_hole+r_tube*cos(vv)).*sin(uu); r_tube*sin(vv)];

% sample uniformly from set
X = [X_sphere, X_torus];
inds = sample_cluster ( X, r, 2*n );
X = X(:,inds);