function [X, ints] = generate_mobius ( n, r )
% function [X, ints] = generate_mobius ( n, r );
% This function generates random data for a Mobius strip along with
% the parameterization of the Mobius strip.  If p is true then a plot
% is also produced.
%
% INPUTS: n -- number of points on sphere
%
% OUTPUTS: X -- Mobius strip embedding in 3d (x,y,z) coordinates
%          ints -- the boundary indices
%
% S. Martin
% 2/28/2008

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z altitute from -1 to 1
rho = 2*rand(s,1,n)-1;

% find x,y,z using spherical transforms
x = (1+rho/2.*cos(theta/2)).*cos(theta);
y = (1+rho/2.*cos(theta/2)).*sin(theta);
z = rho/2.*sin(theta/2);

X = [x;y;z];

% sample from boundary first
boundary = find(abs(rho)>1-.05);

% next sample from manifold, keeping boundary fixed
[X,ints] = sample_surface ( X, boundary, r, n );