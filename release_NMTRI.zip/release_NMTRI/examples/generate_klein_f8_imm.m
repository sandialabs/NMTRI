function X = generate_klein_f8_imm ( n, r )
% function X = generate_klein_f8_imm ( n, r );
% This function generates n points uniformly subsampled from a Klein
% bottle immersed in R^3 using the figure 8 parameterization.
%
% INPUT: n -- number of points on placed randomly on Klein bottle.
%        r -- radius to use for uniform subsampling
%
% OUTPUT: X -- points (as columns) on Klein bottle immersion in R^3
%
% NOTES:
% (1) Actual number of returned points will be less than n
%     depending on the value of r.
%
% S. Martin
% 3/31/2009

% generate random points on manifold

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',1);

u = 2*pi*rand(s,1,n);
v = 2*pi*rand(s,1,n);
a = 3;

% put point in R^3
X = [(a + cos(u/2).*sin(v) - sin(u/2).*sin(2*v)).*cos(u);...
     (a + cos(u/2).*sin(v) - sin(u/2).*sin(2*v)).*sin(u);...
     sin(u/2).*sin(v) + cos(u/2).*sin(2*v)];

% sample uniformly from manifold
inds = sample_cluster ( X, r, n );
X = X(:,inds);