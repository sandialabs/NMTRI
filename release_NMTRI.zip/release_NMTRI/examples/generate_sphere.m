function X = generate_sphere ( n, r );
% function X = generate_sphere ( n, r );
% This function generates random data for a sphere along with
% the parameterization of the sphere.
%
% INPUTS: n -- number of points on sphere
%         r -- minimum distance to use for uniform sampling
%
% OUTPUTS: X -- sphere embedding in 3d (x,y,z) coordinates
%
% S. Martin
% 3/12/2009

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z direction angle
rho = rand(s,1,n)*pi;

% find x,y,z using spherical transforms
x = cos(theta).*sin(rho);
y = sin(theta).*sin(rho);
z = cos(rho);
X = [x;y;z];

% sample uniformly from manifold
inds = sample_cluster ( X, r, n );
X = X(:,inds);