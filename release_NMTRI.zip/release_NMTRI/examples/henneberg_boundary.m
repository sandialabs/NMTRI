function [B, boundary, b_nbhds] = henneberg_boundary ( nbhds, ints, ... 
    X, P, bound_e, alpha_e, nbhd_e )
% function [boundary, b_nbhds] = henneberg_boundary ( nbhds, ints, ... 
%    X, P, bound_min_dist, bound_e, alpha_e, nbhd_e )
% Compute boundary neighborhoods for Henneberg surface.  Works by
% using alpha shapes in the r,phi space.
%
% INPUTS: nbhds -- cell array with neighborhood indices
%         ints -- intersection indices
%         X -- coordinates with points as columns
%         P -- parameters corresponding to coordinates in X
%             (first row r, second row phi)
%         bound_min_dist -- sampling rate for boundary
%         bound_e -- boundary tolerances (width of r) for using alpha
%                    shapes (1) for r=.4 boundary, (2) for r=.6 boundary
%         alpha_e -- alpha boundary sphere (1) for r=.4, (2) for r = .6
%         nbhd_e -- neighborhood size to use for re-distributing points
%                   near intersection boundaries for triangulation
%
% OUTPUTS: B -- new data set, with reduced boundary points
%          bound_ints -- boundary and intersection indices
%          b_nbhds -- new cell array with original intersections
%                     undisturbed, but with boundary added as
%                     new intersections
%          W_inds -- indices into W
%
% NOTE: The ashape command was obtained from the Mathworks file share, along
%       with aslib.m, asdemo.m and the html folder.
% 
% S. Martin
% 4/3/2009

% we use bound_4 for r=.4 and bound_6 for r = .6
bound_4 = find(P(1,:)<.4+bound_e(1));
bound_6 = find(P(1,:)>.6-bound_e(2));

% sort boundaries into unique order (for ashape.m)
[uniq_bound,bound_4_uniq] = unique(P(:,bound_4)','rows');
[uniq_bound,bound_6_uniq] = unique(P(:,bound_6)','rows');
bound_4 = bound_4(bound_4_uniq);
bound_6 = bound_6(bound_6_uniq);

% check uniqueness
if sum(sum(abs(unique(P(:,bound_4)','rows')'-P(:,bound_4)))) | ...
   sum(sum(abs(unique(P(:,bound_6)','rows')'-P(:,bound_6))))
    error ('non-unique boundary elements found.');
end

% find alpha shape for boundary 4
p_4 = ashape(P(1,bound_4),P(2,bound_4),alpha_e(1),'-g');
alpha_4 = bound_4 (find(p_4.dmod>0));
alpha_4 = alpha_4 (find(P(1,alpha_4)<.4+bound_e(1)/2));

% find alpha shape for boundary 6
p_6 = ashape(P(1,bound_6),P(2,bound_6),alpha_e(2),'-g');
alpha_6 = bound_6 (find(p_6.dmod>0));
alpha_6 = alpha_6 (find(P(1,alpha_6)>.6-bound_e(2)/2));

% show plots for verification
%figure(1);
%plot_alpha(p_4);
%figure(2);
%plot_alpha(p_6);
%figure(3);
%plot_boundary ( X, ints, alpha_4, alpha_6 );

% get boundary not including intersections
num_X = size(X,2);
boundary = zeros(1,num_X);
boundary (alpha_4) = 1;
boundary (alpha_6) = 1;
boundary (ints) = 0;
boundary = find(boundary);

% compute boundary neighborhoods (only keep neighborhoods which
% do not contain intersections)
b_nbhds = nbhds;
[sort_r,sort_r_inds] = sort(P(1,ints));
bound_ints = [sort_r_inds(1:4), sort_r_inds((end-3):end)];
for i = 1:length(boundary)
    b_nbhds{boundary(i)} = intersect(nbhds{boundary(i)},...
        [boundary,bound_ints]);
end

% move boundary away from other points
P(1,alpha_4) = .4;
P(1,alpha_6) = .6;
P(1,bound_ints(1:4)) = .4;
P(1,bound_ints(5:8)) = .6;
B = henneberg ( P(1,:),P(2,:) );

% get not boundary and not ints
not_bound_ints = ones(1,num_X);
not_bound_ints(boundary) = 0;
not_bound_ints(ints) = 0;
not_bound_ints = find(not_bound_ints);

% move points near boundary intersections closer on outside ring
for i = 1:8
    
    % look for nearest intersection non boundary
    D = L2_distance(X(:,bound_ints(i)),X(:,ints));
    [sort_D,sort_D_ind] = sort(D);
    nearest_int = ints(sort_D_ind(2));
    
    % get neighborhood of boundary intersection
    D = L2_distance(X(:,bound_ints(i)),X(:,not_bound_ints));
    nbhd_D = not_bound_ints(find(D<nbhd_e));
    
    % examine each point in neighborhood and isolate quadrant
    for j = 1:length(nbhd_D)
        
        % first isolate planar neighborhood
        planar_nbhd = intersect(nbhd_D,b_nbhds{nbhd_D(j)});
        num_planar_nbhd = length(planar_nbhd);
        
        % get closest boundary vector with angle <= pi/2 to our point
        % (we actually use pi/2+angle_err)
        
        % get two closest boundary points to boundary intersection
        bound_nbhd = intersect(b_nbhds{nbhd_D(j)},boundary);
        bound_nbhd_D = L2_distance ( X(:,bound_ints(i)), X(:,bound_nbhd) );
        [bound_nbhd_sort,bound_nbhd_sort_ind] = sort ( bound_nbhd_D );
        bound_nbhd = bound_nbhd(bound_nbhd_sort_ind(1:2));
        
        % pick boundary with smallest angle as the one on our side
        vec1 = repmat(X(:,nbhd_D(j)) - X(:,bound_ints(i)),1,2);
        vec2 = X(:,bound_nbhd)-repmat(X(:,bound_ints(i)),1,2);
        angle_nbhd = acos ( sum(vec1.*vec2)./sqrt(sum(vec1.*vec1).*sum(vec2.*vec2)) );
        [min_angle_nbhd,min_angle_ind] = min(angle_nbhd);
        min_angle_ind = bound_nbhd(min_angle_ind);
        
        % get quadrant neighborhood (everything that has a smaller angle
        % than our two vectors)
        vec1 = X(:,min_angle_ind)-X(:,bound_ints(i));
        vec2 = X(:,nearest_int)-X(:,bound_ints(i));
        cut_off_angle = acos ( vec1'*vec2/sqrt(norm(vec1)*norm(vec2)) );
        vec1 = X(:,planar_nbhd) - repmat(X(:,bound_ints(i)),1,num_planar_nbhd);
        vec2 = repmat(X(:,min_angle_ind)-X(:,bound_ints(i)),1,num_planar_nbhd);
        angle_planar = acos ( sum(vec1.*vec2)./sqrt(sum(vec1.*vec1).*sum(vec2.*vec2)) );
        quad_nbhd = planar_nbhd(find(angle_planar<cut_off_angle));
        
        % compute better location for nearest quadrant triangulation point
        better_point = (X(:,nearest_int) + X(:,min_angle_ind))/2;
        
        % move nearest quadrant neighbor to the better point
        better_point_D = L2_distance ( better_point, X(:,quad_nbhd) );
        [sort_better,sort_better_ind] = sort(better_point_D);
        nearest_quad_point = quad_nbhd(sort_better_ind(1));
        B(:,nearest_quad_point) = better_point;
        
        % check results for debugging    
        if 0
           plot3(B(1,ints),B(2,ints),B(3,ints),'rx');
           hold on
           %plot3(B(1,bound_nbhd),B(2,bound_nbhd),B(3,bound_nbhd),'m.');
           plot3(B(1,nearest_quad_point),B(2,nearest_quad_point),B(3,nearest_quad_point),'y*');
           plot3(better_point(1),better_point(2),better_point(3),'g*','MarkerSize',12);
           plot3(B(1,quad_nbhd),B(2,quad_nbhd),B(3,quad_nbhd),'b.');
           plot3(B(1,min_angle_ind),B(2,min_angle_ind),B(3,min_angle_ind),'m.');
           plot3(B(1,boundary),B(2,boundary),B(3,boundary),'bo');
           plot3(B(1,nbhd_D(j)),B(2,nbhd_D(j)),B(3,nbhd_D(j)),'r*','MarkerSize',12);
           plot3(B(1,planar_nbhd),B(2,planar_nbhd),B(3,planar_nbhd),'ro');
           plot3(B(1,nearest_int),B(2,nearest_int),B(3,nearest_int),'go');
           plot3(B(1,bound_ints(i)),B(2,bound_ints(i)),B(3,bound_ints(i)),'k*','MarkerSize',12);
           hold off
           pause
        end
    
    end
    
end

return

% show boundary neighborhoods for verification
figure(4);
for i = 1:length(boundary)
  plot3(X(1,boundary),X(2,boundary),X(3,boundary),'.');
  hold on
  plot3(X(1,boundary(i)),X(2,boundary(i)),X(3,boundary(i)),'y*');
  plot3(X(1,b_nbhds{i}),X(2,b_nbhds{i}),X(3,b_nbhds{i}),'go');
  plot3(X(1,ints),X(2,ints),X(3,ints),'rx');
  hold off
  pause
end

function plot_alpha (p)

% plot all elements
p=p.f.gall(p);

% remove ALPHA CIRCLES
p=p.f.gcir(p,1);

% change DATA MARKERS to (+);
set([p.h.AS_dat{:}],'marker','+');

% mark ALPHA LINE nodes and edges
% using index fields returned in P
% for an explanation of P fields see: ASLIB -f

ix=p.dmod==4;
line(p.x(ix),p.y(ix),...
        'marker','o',...
        'markersize',8,...
		'markerfacecolor',[.5 .5 0],...
		'linestyle','none',...
		'color',[0 0 0]);
ix=p.amod==2;
line(p.x(p.seg(ix,:)).',p.y(p.seg(ix,:)).',...
		'linewidth',4,...
		'color',[0 0 0]);
    
axis equal
axis square
        
function plot_boundary (X,ints,bound_1,bound_2)
               
% make plot for debugging
plot3(X(1,:),X(2,:),X(3,:),'.');
hold on
plot3(X(1,ints),X(2,ints),X(3,ints),'rx');
%hold on
plot3(X(1,bound_1),X(2,bound_1),X(3,bound_1),'go');
plot3(X(1,bound_2),X(2,bound_2),X(3,bound_2),'ko');
hold off

function H = henneberg ( r, phi )

x = 2*(r.^2 - 1).*cos(phi)./r - 2*(r.^6-1).*cos(3*phi)./(3*r.^3);
y = -(6*r.^2.*(r.^2-1).*sin(phi) + 2*(r.^6-1).*sin(3*phi))./(3*r.^3);
z = 2*(r.^4+1).*cos(2*phi)./(r.^2);

H = [x;y;z];
