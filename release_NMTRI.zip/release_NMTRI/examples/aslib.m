% ASLIB	an ALPHA SHAPE function library
%
%	- use ASHAPE as a convenient wrapper
%	- for instructions/options see: HELP ASHAPE
%
% SYNTAX
% -------------------------------------------------------------------------------
%	FH = ASLIB;
%		returns a structure of handles to ASLIB functions
%
%	     ASLIB  s  |  -s
%	P  = ASLIB('s' | '-s' | 0);
%		shows FUNCTION names/actions and a GLOSSARY of terms
%
%	     ASLIB  f  |  -f
%	P  = ASLIB('f' | '-f' | 1);
%		shows FIELD names/contents
%
%	     ASLIB  o  |  -o
%	P  = ASLIB('o' | '-o' | 2);
%		shows OPTIONS
%
%	     ASLIB(P);
%	P  = ASLIB(P);
%	C  = ASLIB(P,1);
%		checks validity of P
%
% OUTPUT
% -------------------------------------------------------------------------------
%  P	returns an ASLIB structure with empty/default fields
%  P.f	holds FH
%  C	returns an summary structure in quiet mode
%
% EXAMPLES
% -------------------------------------------------------------------------------
%	P = ASHAPE(...)		compute ALPHA COMPONENTS and return results in P
%	P.f.gall(P)		show		all components
%	P.f.gall(P,1)		delete		all components
%	P.f.gcir(P,opt)		show		all ALPHA CIRCLES with new options
%	P.f.gcir(P,1)		delete		all ALPHA CIRCLES
%	-or-
%	FH = aslib;		get function handles to most recent functions
%	FH.gall(P);		equivalent to	P.f.gall(P)
%	-or-
%	fun=P.f.gcir;		set an alias
%	fun(P,opt);		equivalent to	P.f.gcir(P,opt)
%	...
%	set([P.h.AS_con{:}],.)	redefine	all ALPHA NODE props
%	...
%	P = ASHAPE(P,[opt]);	re-compute a previous ASLIB result
%				using the most recent library version

% created:
%	us	05-Feb-1994
% modified:
%	us	24-Apr-2007 15:34:15

%--------------------------------------------------------------------------------
function	fh=aslib(varargin)

	if	nargin
	if	nargin  >= 1
		ftmp=ashelp(varargin{:});
	end
	if	nargout
		fh=ftmp;
	end
		return;
	end
		fh=asfun;
		return;
%--------------------------------------------------------------------------------
%--------------------------------------------------------------------------------
% ASLIB VERSION / HELP / PARAMETER INITIALIZER
%--------------------------------------------------------------------------------
function	[vtag,vid,mag]=asver(mag)
% - version tracker
%   *** only change <vid> if functions/fields change ***

		vtag=		'24-Apr-2007 15:34:15';
		vid =5.02; %	'12-Mar-2005';
		return;
%--------------------------------------------------------------------------------
function	c=aschk(p,mod)

% - check version

		magic='ASHAPE';
	if	nargin < 2
		mod=1;
	end

		[ver,vid,mag]=asver(magic);
		c.r=0;
		c.msg='';
		c.class=class(p);
		c.p=p;

	if	isstruct(p)
	if	isfield(p,'magic')
	if	strcmp(p.magic,mag)
	if	p.aslibvid >= vid
		return;
	else
		c.msg=sprintf(...
			['ASLIB> version mismatch\n',...
			 'ASLIB> input   version  %7.2f (%s)\n',...
			 'ASLIB> current version  %7.2f (%s)\n',...
			 'ASLIB> run                       p=ashape(p.x,p.y,p.r);'],...
			p.aslibvid,p.aslibver,vid,ver);
		c.r=1;
	end
	else
		c.msg=sprintf(...
			'ASLIB> input is not a valid ASLIB structure:\nASLIB> missing field <magic=%s>',mag);
		c.r=2;
	end
	else
		c.msg=sprintf(...
			'ASLIB> input is not a valid structure:\nASLIB> missing field <magic>');
		c.r=3;
	end
	else
		c.msg=sprintf(...
			'ASLIB> input is not a structure:\nASLIB> class %s',c.class);
		c.r=4;
	end
	if	mod
		error(c.msg);
	end
		return;
%--------------------------------------------------------------------------------
function	fh=ashelp(varargin)

% - common help engine
%   *** NOTE formatting is optimized for fixed width fonts (eg, courier new) ***

		opt=varargin{1};
	if	(~isnumeric(opt) || (numel(opt) ~= 1)) && ~ischar(opt)
		c=aschk(opt,0);
	if	nargin > 1
		fh=c;
		return;
	end
	if	~c.r
		disp(sprintf('ASLIB> input is a valid ASLIB parameter structure'));
	else
		disp(c.msg);
	end
		fh=opt;
		return;
	end
		fh=apars(1);

		rbreak=repmat('-',1,23);
		delimiter=repmat('-',1,128);
	switch	opt

% - functions
	case	{0 's' '-s'}
		txt={
'FH = ASLIB;'
'     returns ASLIB function handles in structure FH'
' '
'FH			action		(A=alpha)'
delimiter
[rbreak ' COMPUTATIONAL ENGINES']
'.aini(x,y,r,opt)	initialize parameters and compute all possible'
'			segments from delaunay tessellation'
'			- x	x coordinates of input'
'			- y	y coordinates of input'
'			- r	radius        of circle'
'			- opt	option(s)'
' P = FH.aini(..)	- P	common ASLIB parameter structure'
'    .circ(P,xoff,yoff)	create an A circle template'
'			- xoff	x offset	[def: 0]'
'			- yoff	y offset	[def: 0]'
'			- P.r	radius'
'			- P.ang	resolution	[def: 1, <-a>]'
'.mseg(P)		evaluate A nodes/A edges'
'    .cfit(P,tix)	fit an A circle to two points'
'			- tix	index into P.dt'
'    .cchk(P)		check whether x/y points are within an A circle'
'.mcon(P)		compute list of connected A shapes'
'.mpat(P)		compute A patches within A shapes'
'    .cpat(P)		find best fitting next A edge at a n>1 degree A node'
'			using closest angle (and torsion of direction)'
'			from the preceding A edge'
[rbreak ' GRAPHICS ENGINES']
'.gall(P,opt)		show/delete all components:'
'.gdat(P,opt)		show/delete     data'
'.gcir(P,opt)		show/delete     A circles'
'.gseg(P,opt)		show/delete     A edges'
'.gcon(P,opt)		show/delete     A nodes'
'.gpat(P,opt)		show/delete A patches'
'			- opt'
'			  a numeric	delete component'
'			  ''-opt(s)''	redraw component using new option(s)'
delimiter
'GLOSSARY		(A=alpha)'
delimiter
'segment			a line connecting two x/y vertices as determined'
'			from delaunay tessellation'
'A circle		a circle to find vertices/segments that form'
'			an A shape'
'A node			a vertex  that is part of an A shape/A patch'
'A edge			a segment that is part of an A shape/A patch'
'A line			a two-sided A edge'
'A shape			connected A edges that form an unique shape'
'A patch			a closed digraph of A edges within an A shape'
'			that can be used as input to <patch>'
delimiter
'NOTE'
'	for an explanation of fields	see: ASLIB -f'
'	for    options			see: ASLIB -o'
		};

% - fields
	case	{1 'f' '-f'}
		txt={
'P.field		contents	(A=alpha)'
delimiter
'.f		function handles to ASLIB functions'
'.h.X		cells of graphics handles'
'			.AS_bar	= colorbar'
'			.AS_dat	= x/y data points'
'			.AS_cir	= A circles'
'			.AS_seg	= A edges'
'			.AS_con	= A nodes'
'.opt		run-time options'
'.flg		option flags and run-time parameters'
'.m		nr of all data points'
'.n		nr of unique and sorted data points'
'.x/.y		x/y coordinates of unique and sorted data points'
'.dmod		data point spec:'
'			0  = not an A node: inside A shape|singleton'
'			2  = A node'
'			4  = n>1 degree A node'
'			6+ = A node bifurcation between A edges of type 2&4'
'.nd		nr of unique segments      from delaunay tessellation'
'.dt		vertex indices of segments from delaunay tessellation'
'.drng		min/max of .dl'
'.dix		last index of sorted .dl <= .r'
'.dl		length/2 of segments'
'.r		radius of A circle'
'.ang		resolution of A circle				[def: 1 deg]'
'.xcir/.ycir	x/y coordinates of A circle template (.r/.ang)'
'.nseg		nr of A edges'
'.cen		x/y coordinates of centers of A circles'
'.seg		A edges (radius    search)'
'.segp		A edges (inpolygon search)			[use: -t]'
'.amod		A edge spec:'
'			1  = one-sided A edge (polygon|bifurcation)'
'			2  = two-sided A edge (line)'
'.nshape		nr of A shapes'
'.xshape		index of .seg into each unique A shape'
'.lshape		length of A shapes'
'.ashape		indices of A edges forming a unique A shape'
'.pmod		A patch connection mode				[def: ''angle'']'
'.npatch		nr of A patches'
'.xpatch		index of A shapes into A patches'
'.spatch		size of .apatch'
'			rows = nr of A shapes used'
'			cols = nr of A patch(es)/A shape'
'.lpatch		length of each A patch'
'.apatch		node indices of each A patch'
delimiter
'NOTE'
'	for an explanation of functions	see: ASLIB -s'
'	for a  glossary of terms	see: ASLIB -s'
'	for    options			see: ASLIB -o'
		};

% - options
	case	{2 'o' '-o'}
 		txt={
'OPT	args		contents	(A=alpha)'
delimiter
[rbreak ' PROCESSING']
' -a	degrees		angular resolution of A circles			[def: 1 deg]'
'				note: used for display and <-t>'
' -cd	diameter	diameter of A circles				[def: .aini(.,.,2*r)]'
' -cr	radius		radius   of A circles				[def: .aini(.,.,  r)]'
' -pta	none		find optimal A patches using the preceding'
'			A edge''s angle and direction of torsion		[def: angle]'
' -qh	{qhull-opt[s]}	set new qhull options				[def: {''QJ'',''Pp''}]'
'			for more options see:'
'				http://www.qhull.org'
[rbreak ' GRAPHICS']
' -bc	none		keep/plot .cen for both A circles/edge		[def: first match only]'
' -nc	none		do NOT keep/plot .cen for A circles'
' -am	none		use A shape colors to render A patches		[def: red>green>yellow>blue]'
' -cm	colormap(nc)	use <colormap> to render connected A shapes	[def: red>blue]'
'				note: <nc> colors are recycled'
' -cm	''colormap''	use the <''colormap''> function'
'				note: the colormap will be computed at'
'				run-time from <colormap(.nshape)>'
' -pc	[r g b]		define A patch selection color			[def: [0 1 1]]'
' -pp	none		plot A patches at runtime			[def: .gall(P)]'
' -g	none		do NOT plot at run-time				[def: .gall(P)]'
'				use:	P.f.gall(p,[opt]);'
'					    to plot all components'
'					P.f.gpat(p,[opt]);'
'					    to plot A patches'
[rbreak ' MISCELLANEOUS']
' -t	none		test x/y data points using ML''s <inpolygon>'
'			and compare results with the def <radius>'
'			search engine'
'				the input to <inpolygon> is the'
'				A circle computed by .circ and'
'				depends on parameters .r/.ang'
'				note: this may take longer!'
' -v	none		display progress at run-time			[def: quiet]'
' -wb	none		show progress bars				[def: none]'
delimiter
'NOTE'
'	for an explanation of functions	see: ASLIB -s'
'	for an explanation of fields	see: ASLIB -f'
'	for a  glossary    of terms	see: ASLIB -s'
		};

	otherwise
		disp(sprintf('ASLIB> unknown option!\n'));
		help(mfilename);
		return;
	end
		disp(char(txt));
		return;
%--------------------------------------------------------------------------------
function	p=apars(mod)

% - common ASLIB parameter structure
% - note several fields are removed after computation

		magic='ASHAPE';
		zint=int32([]);

		[ver,vid,p.magic]=asver(magic);
		p.aslibver=ver;
		p.aslibvid=vid;
		p.f=asfun;
		p.h.pref='AS_';
		p.h.([p.h.pref 'bar'])={[]};
		p.mos=version;
		p.section_1='--- run-time parameters ----------------';
		p.time=datestr(clock);
		p.runtime=clock;
		p.opt=[];
		p.flg=[];
		p.section_2='--- data -------------------------------';
		p.m=0;
		p.n=0;
		p.x=[];
		p.y=[];
		p.dmod=zint;
		p.section_3='--- delaunay tessellation segments -----';
		p.nd=0;
		p.dt=zint;
		p.drng=[];
		p.dix=0;
		p.dl=[];
		p.section_4='--- alpha circle template --------------';
		p.r=0;
		p.ang=0;
		p.xcir=0;
		p.ycir=0;
		p.section_5='--- alpha edges ------------------------';
		p.nseg=0;
		p.cen=[];
		p.seg=zint;
		p.segp=zint;
		p.amod=zint;
		p.section_6='--- alpha shapes -----------------------';
		p.nshape=0;
		p.xshape=zint;
		p.lshape=zint;
		p.ashape={};
		p.section_7='--- alpha patches ----------------------';
		p.pmod='angle';
		p.npatch=0;
		p.xpatch=zint;
		p.spatch=zint;
		p.lpatch=zint;
		p.apatch={};
	if	nargin && mod == 1
		return;
	end
% - temporary fields
%   removed after computation
		p.cfn=fieldnames(p);
		p.cflg=false;
		p.cmsg='';
		p.r2=0;
		p.cr=[];
		p.xp=[];
		p.yp=[];
		p.ix=zint;
		p.cx=[];
		p.cy=[];
		p.ip=[];
		p.op=[];
		p.tfn='must remove itself!';
		p.tfn=fieldnames(p);
		return;
%--------------------------------------------------------------------------------
function	fh=asfun

% - library functions

		magic='ASLIB';

		fh.magic=magic;
		[fh.ver,fh.vid]=asver(magic);
%   computational engines
		fh.section_1='--- computational engines --------------';
		fh.aini=@aini;	% common initializer
		fh.circ=@circ;	%	create circle
		fh.mseg=@mseg;	% compute A edges
		fh.cfit=@cfit;	%	fit circle to rad/2pts
		fh.cchk=@cchk;	%	check region for pts inside circle
		fh.mcon=@mcon;	% create tree of unique A shapes
		fh.mpat=@mpat;	% compute A patches
		fh.cpat=@cpat;	%	find next A edge at n>1 dim A nodes
%   graphics engines
		fh.section_2='--- graphics engines -------------------';
		fh.gall=@gall;	% show all components
		fh.gdat=@gdat;	% show data
		fh.gcir=@gcir;	% show A circles
		fh.gseg=@gseg;	% show A shape edges
		fh.gcon=@gcon;	% show A shape nodes
		fh.gpat=@gpat;	% show A patches
%   utilities
		return;
%--------------------------------------------------------------------------------
function	p=aini(x,y,r,varargin)

% - initialize common ASLIB parameter structure

% - return empty ASLIB structure
	if	~nargin
		p=apars(1);
		return;
	end

% - return clean structure
	if	nargin < 4 && isstruct(x)
		p=x;
		aschk(p,1);
	if	isfield(p,'tfn')
		ix=ismember(p.tfn,p.cfn);
		p=rmfield(p,p.tfn(~ix));
		vdisp(p,sprintf('      done aslib:  %36.3fs',...
				p.runtime));
	end
		return;
	end

% - set/check input parameters
	if	numel(x) < 3 || numel(y) < 3
		error('ASLIB> too few x/y data points: [%-1d/%-1d]',numel(x),numel(y));
	end
	if 	numel(x) ~= numel(y)
		error('ASLIB> nr of x/y data points do NOT match: [%-1d/%-1d]',numel(x),numel(y));
	end

		n=numel(x);
		xy=asunique([x(:) y(:)]);
		p=apars;
		p.f=aslib;
		p.x=xy(:,1);
		p.y=xy(:,2);
		p.m=n;
		p.n=numel(p.x);
	if	p.n < 3
		error('ASLIB> too few unique x/y data points for delaunay tessellation: [%-1d]',p.n);
	end
		p.r=r;
		p.ang=1;

% - set/check options
		p=asopt(p,0,varargin{:});

% - set default parameters
%   create A circle template
	if	~isempty(p.flg.cdia)
		p.r=.5*p.flg.cdia;
	elseif	~isempty(p.flg.crad)
		p.r=p.flg.crad;
	end
	if	p.r <= 0
		error('ASLIB> alpha circle radius <= 0: [%g]',r);
	end
	if	mod(p.flg.dang,360) <= 0
		error('ASLIB> modulus of alpha circle angle <= 0: [%g]',p.flg.dang);
	end
		p.r2=(p.r*p.r)+eps;	% FP!
		p=circ(p,0,0);

		vdisp(p,sprintf('processing aslib:'));
		vdisp(p,sprintf('processing data:     %7d/%7d  (%5.1f%%)',...
				p.n,p.m,100*p.n/p.m));

% - get segments
		ti=clock;
		p=asdelaunay(p);
		to=clock;
		vdisp(p,sprintf('      done data:  %37.3fs',...
				etime(to,ti)));
		return;
%--------------------------------------------------------------------------------
function	p=asopt(p,mod,varargin)

% - set/check options

		aschk(p,1);

%   default ASLIB options
		pscol=[0 1 1];		% patch selection color
%   default QHULL options
		qopt={'QJ','Pp'};
%   user options	opt	flag	ini	def	nr parameters
%			---------------------------------------------
		opt={
%   processing
			'-a'	'dang'	1	1	1
			'-cd'	'cdia'	[]	[]	1
			'-cr'	'crad'	[]	[]	1
			'-pta'	'pmod'	0	1	0
			'-qh'	'qopt'	qopt	qopt	1
			'-wb'	'wbar'	false	true	0
%   graphics
			'-bc'	'bcir'	false	true	0
			'-nc'	'ncir'	false	true	0
			'-am'	'amap'	false	true	0
			'-cm'	'cmap'	[]	[]	1
			'-pc'	'pscol'	pscol	[]	1
			'-pp'	'pflg'	false	true	0
			'-g'	'gflg'	true	false	0
%   other
			'-t'	'tflg'	false	true	0
			'-v'	'vflg'	false	true	0
		};

% - set/check options
		p.opt=varargin;
	if	~mod
	for	i=1:size(opt,1)
		p.flg.(opt{i,2})=opt{i,3};
	end
	end

	if	nargin > 2
	for	i=1:size(opt,1)
		ix=find(strcmp(opt(i,1),varargin));
	if	~isempty(ix)
	if	~opt{i,5}
		p.flg.(opt{i,2})=opt{i,4};
	else
		ix=ix+1:ix+opt{i,5};
	if	ix(end) > length(varargin)
		p.flg.(opt{i,2})=opt{i,4};
	else
		p.flg.(opt{i,2})=varargin{ix};
	end
	end
	end
	end
	end

	if	p.flg.pmod
		p.pmod='search mode: torsion/angle';
	else
		p.pmod='search mode: angle';
	end
		return;
%--------------------------------------------------------------------------------
%--------------------------------------------------------------------------------
% ASLIB FUNCTIONS
%--------------------------------------------------------------------------------
function	p=mseg(p)

		aschk(p,1);
	if	~p.nd || isempty(p.dix) || ~p.dix
		return;
	end

		wh=0;
		rv=[100 80 60 40 20];
		txt=sprintf('processing edges:    %7d/%7d  (%5.1f%%)',...
			p.dix,p.nd,100*p.dix/p.nd);
	if	p.flg.wbar
		wh=waitbar(0,txt);
		set(wh,'name','ASLIB segmenting...');
		pause(0.01);
	end
		vdisp(p,txt);

		ti=clock;
	for	i=1:p.dix
		r=i/p.dix;
		rf=floor(100*r);
	if	wh
		waitbar(r,wh);
	end

		p=p.f.cfit(p,i);	% call <p>'s version!
		p=p.f.cchk(p);		% ...

	if	find(rf==rv)
		to=clock;
		vdisp(p,sprintf('      done edges:    %7d %7d%% %17.3fs',...
				i,rf,etime(to,ti)));
		rv(end)=[];
	end

	end
		to=clock;

	if	wh
		delete(wh);
	end
		vdisp(p,sprintf('      done edges:    %7d %26.3fs',...
				p.nseg,etime(to,ti)));
		return;
%--------------------------------------------------------------------------------
function	p=circ(p,xoff,yoff)

% - create a circle at offset xoff/yoff with radius p.r and resolution p.ang

		p.ang=mod(p.flg.dang,360);
		a=0:p.ang:360;
	if	a(end) < 360
		a=[a 360];
	end
		p.xcir=xoff+p.r*cosd(a);
		p.ycir=yoff+p.r*sind(a);
		return;
%--------------------------------------------------------------------------------
function	p=cfit(p,tix)

% - fit a circle with radius .r to two points .xp/.yp

% created:
%	us	11-Aug-1987
% modified:
%	us	12-Jul-2004
%	us	20-Jan-2005	/ TMW <aslib>

	if	nargin < 2
		return;
	end

		p.cflg=false;
		p.cmsg='';
		p.ix=p.dt(tix,:);
		p.xp=p.x(p.ix);
		p.yp=p.y(p.ix);
		p.cx=[];
		p.cy=[];

		dx=diff(p.xp);
		dy=diff(p.yp);
		p.cr=.5*sqrt(dx.^2+dy.^2);
	if	p.cr == 0
		p.cmsg='cannot fit a single point';
		return;
	end
	if	p.cr > p.r
		p.cmsg='radius too small';
		return;
	end
		p.cflg=true;
		xm=.5*sum(p.xp);
		ym=.5*sum(p.yp);
		r2=sqrt(p.r.^2-p.cr.^2);
		cr=2*p.cr;
		p.cx=[xm+r2*-dy/cr xm-r2*-dy/cr];
		p.cy=[ym+r2* dx/cr ym-r2* dx/cr];
		return;
%--------------------------------------------------------------------------------
function	p=cchk(p)

	if	~p.cflg
		return;
	end

% - remove current segment (severe FP problems!)
		xx=p.x;
		yy=p.y;
		xx(p.ix)=nan;
		yy(p.ix)=nan;

		ccnt=0;
	for	i=1:2
		aflg=0;
		bflg=0;
		cx=p.xcir+p.cx(i);
		cy=p.ycir+p.cy(i);
% - only check circle's proximity
		xt=find(xx>=p.cx(i)-p.r & xx<=p.cx(i)+p.r & ...
			yy>=p.cy(i)-p.r & yy<=p.cy(i)+p.r);
		rx=xx(xt);
		ry=yy(xt);

% - check against ML's <inpolygon> using
%   finite (!) circular polygon p.xcir/p.ycir based on p.ang [def: 1 deg]
	if p.flg.tflg
		[p.ip,p.op]=inpolygon(rx,ry,cx,cy);
	if	sum(p.ip) == 0 || sum(p.op) > 1
		p.segp=[p.segp;p.ix];
		aflg=1;
		ff=p.ip;
		gg=p.op;
	end
	end

		rr=(rx-p.cx(i)).^2+(ry-p.cy(i)).^2;
		iz=(rr<=p.r2);
		p.ip=iz~=0;
%		ir=(rr==p.r2);		% points on radius
%		p.op=ir~=0;
	if	sum(p.ip) == 0
		ccnt=ccnt+1;
	if	ccnt == 1
		p.nseg=p.nseg+1;
		p.cen=[p.cen;[p.cx(i) p.cy(i)]];
		p.seg=[p.seg;p.ix];
		p.amod=[p.amod;ccnt];
	elseif	ccnt == 2 && p.flg.bcir
		p.nseg=p.nseg+1;
		p.cen=[p.cen;[p.cx(i) p.cy(i)]];
		p.seg=[p.seg;p.ix];
		p.amod(end)=ccnt;
		p.amod=[p.amod;ccnt];
	else
		p.amod(end)=p.amod(end)+1;
	end
		bflg=1;
	end
	if	p.flg.tflg && (aflg~=bflg)
		disp(sprintf('mismatch> inpoly=%1d radius=%1d',aflg,bflg));
		line(cx,cy,'color',[0 0 0]);
		gdat(p);
		line(p.xp,p.yp);
		disp([ff,gg].');
		keyboard
	end
	end
	if	p.flg.ncir
		p.cen=[];
	end
		p.dmod(p.ix,1)=p.dmod(p.ix,1)+ccnt;
		return;
%--------------------------------------------------------------------------------
function	p=mcon(p)

% - find unique A shapes

		aschk(p,1);
	if	~p.nseg
		return;
	end

		wh=0;
		txt=sprintf('processing shapes:   %7d',p.nseg);
	if	p.flg.wbar
		cz=0;
		wh=waitbar(0,txt);
		set(wh,'name','ASLIB connecting...');
		pause(0.01);
	end
		vdisp(p,txt);

% - reset A shape tree
		p.nshape=0;
		p.xshape=zeros(p.nseg,1,'int32');
		p.lshape=[];
		p.ashape={};
% - re-index edge indices to obtain a min length vector
		z=reshape(p.seg.',1,[]);
		[dum,zix]=histc(z,asunique(z));
		z=reshape(zix,fliplr(size(p.seg))).';
% - create empty templates only once
		zm=[max(zix) 1];
		zz=zeros(zm,'int32');
		zl=false(zm);

		ti=clock;
% - this is very fast despite the two <while>s!
	while	true

% - find kernel of new distinct A shape
% - note already used edges are marked by <nan>s
		zb=find(z(:,1)==z(:,1));
	if	isempty(zb)
% - no unmarked edge found
		break;
	end

% - set current kernel
		ix=zz;
		ix(z(zb(1),:))=1;
		ixo=ix;
		ir=zl;
		ir(zb(1))=true;

	while	true

% - check whether nodes of remaining (unmarked) edges
%   belong to current kernel
	for	i=zb(1:end).'
		iz=ix(z(i,:));
% - grow kernel and mark edge-index vec
	if	any(iz)
		ix(z(i,:))=1;
		ir(i)=true;
	end
	end
	if	isequal(ix,ixo)
% - current kernel has no new edges
		break;
	end
		ixo=ix;
	end
% - mark all edges of current kernel
		z(ir,:)=nan;
% - save new distinct (connected) A shape
		irx=find(ir);
		p.nshape=p.nshape+1;
		p.ashape{p.nshape,1}=p.seg(irx,:);
		p.lshape(p.nshape)=size(p.ashape{p.nshape},1);
		p.xshape(irx)=p.nshape;

	if	wh
		cz=cz+length(irx);
		waitbar(cz/p.nseg,wh);
	end

	end
		to=clock;

	if	wh
		delete(wh);
	end
		vdisp(p,sprintf('      done shapes:   %7d %26.3fs',...
				p.nshape,etime(to,ti)));

		return;
%--------------------------------------------------------------------------------
function	p=mpat(p)

			aschk(p,1);
		if	~p.nshape
			return;
		end

			wh=0;
			txt=sprintf('processing patches:  %7d',p.nshape);
		if	p.flg.wbar
			wh=waitbar(0,txt);
			set(wh,'name','ASLIB patching...');
			pause(0.01);
		end
			vdisp(p,txt);

			[dum,ixp]=sort(p.lshape,'descend');
			p.xpatch=ixp;

			nr=0;
			ti=clock;
	for	nx=1:p.nshape
			ns=ixp(nx);
			kl=p.lshape(ns);
		if	kl < 2
			break;
		end
			k=p.ashape{ns};
			am=p.amod(p.xshape==ns);
			al=am==2;
			k(al,:)=[];

	if	~isempty(k)
			k=k(:);
			kk=asunique(k);
			[dum,b]=histc(k,kk);

	if	length(b) > 1
			m=reshape(b,[],2);
			m=sortrows(m);
			mr=size(m,1);
			mc=max(m(:));
			s=sparse(1:mr,m(:,1),1,mr,mc);
			s=s+sparse(1:mr,m(:,2),1,mr,mc);

			kn=(1:mr).';
			kz=kn;
			ac=zeros(mc,1);
			kc=ac;
			scc=ac;
			sx=0;
			sc=1;

	while	true
			ix=0;
			a=kn(1);

	while	true
			ix=ix+1;
			ao=a;
			b=find(s(a,:)==1);
		if	~isempty(b)
		if	length(b) == 1
			s(a,b)=nan;
		else
			b=b(1);
		end
			aa=find(s(:,b)==1);
		if	isempty(aa)
			aa=a;
		end
		if	~isempty(aa)
			a=aa(1);
			sx=sx+1;
			scc(sc)=scc(sc)+1;
			kc(sx,1)=sc;
			ac(sx)=kk(b);
		if length(aa) > 1 && scc(sc) > 2
			a=cpat(p,s,sx,aa,ac,b,kk);
		end
			s(a,b)=nan;
			kz(a)=0;
		else
			kz(ao)=0;
		end
		if	isempty(a)
			kn=kz(find(kz));		%#ok
			sc=sc+1;
		if	isempty(kn)
			break;
		end
			a=kn(1);
		if	isempty(find(kc==sc-1,1))
			sc=sc-1;
		end
		end
		else	% isempty(b)
			kn=kz(find(kz));		%#ok
			sc=sc+1;
		if	isempty(kn)
			break;
		end
			a=kn(1);
		if	isempty(find(kc==sc-1,1))
			sc=sc-1;
		end
		end	% ~isempty(b)

	end	% true 1

			kn=kz(find(kz));		%#ok
			sc=sc+1;
		if	isempty(kn)
			break;
		end
		if	isempty(find(kc==sc-1,1))
			sc=sc-1;
		end

	end	% true 2

			nc=0;
			nr=nr+1;
		for	nns=1:max(kc)
			nc=nc+1;
			kix=find(kc==nns);
		if	ac(kix(1)) ~= ac(kix(end))	% should not happen...
			kix=[kix;kix(1)];		%#ok
		end
			p.apatch{nr,nc}=ac(kix);	%#ok
		end
			[lx,lx]=sort(cellfun('length',p.apatch(nr,:)),'descend');
			p.apatch(nr,:)=p.apatch(nr,lx);

	end	% length(b) > 1
	end	% ~isempty(kk)

		if	wh
			waitbar(nx/p.nshape,wh);
		end

	end	% nx=1:p.nshape
			to=clock;

			p.lpatch=int32(cellfun('length',p.apatch));
			p.npatch=sum(sum(p.lpatch>0));
			p.spatch=size(p.apatch);

		if	wh
			delete(wh);
		end
			vdisp(p,sprintf('      done patches:  %7d %26.3fs',...
					p.npatch,etime(to,ti)));

			return;
%--------------------------------------------------------------------------------
function	a=cpat(p,s,sx,aa,ac,b,kk)

% - find next edge at a n>1 degree nodes using
%   direction of torsion
%   closest angle

% - compute torsion of preceding two edges (cross product)
		ia=ac(sx-2:sx);
		x=p.x(ia(2:end))-p.x(ia(1:end-1));
		y=p.y(ia(2:end))-p.y(ia(1:end-1));
		vs=[x y];
		cp1=ascp(vs(1:end-1,:),vs(2:end,:));

% - compute torsion of all edges from current node (cross product)
		[ig,izz]=find(s(aa,:));
		izx=find(izz~=b);
		ig=ig(izx);
		iz=izz(izx);
		iz=kk(iz).';

		iza=ac(sx)*ones(size(iz));
		x=p.x(iz)-p.x(iza);
		y=p.y(iz)-p.y(iza);
		v=[x y];
		u=ones(size(v,1),1)*vs(end,:);
		cp2=ascp(u,v);

	if	~any(cp1) && ~any(cp2)
		a=aa(1);
		return;
	end

% - compute angle between current edge and all edges from current node (dot product)
		vv=sqrt(sum(v.^2,2));
		vu=sqrt(sum(u.^2,2));
		ang=acosd(sum(u.*v,2)./(vv.*vu));

% - find next edge
		as=sign(cp1)==sign(cp2);
		ax=as & as.*ang==max(as.*ang);
		ax=ig(ax);

	if	~p.flg.pmod
		ax=[];
	end
%   using direction of torsion and closest angle
	if	~isempty(ax)
		a=aa(ax);
	else
%   using closest angle only
		ang=abs(ang);
		ax=ang==max(ang);
		ax=ig(ax);
		a=aa(ax);
	end
		return;
%--------------------------------------------------------------------------------
%--------------------------------------------------------------------------------
% ASLIB UTILITIES
%--------------------------------------------------------------------------------
function	p=asdelaunay(p)

% - compute delaunay tessellation and length/2 of its edges
%   only fit circles to edges with lengths/2 <= radius

		p.dt=int32(delaunay(p.x,p.y,p.flg.qopt));
	if	isempty(p.dt)
		error('ASLIB> delaunay tessellation failed for given data');
	end
		p.dt=sort(p.dt,2);
		p.dt=[
			p.dt(:,1) p.dt(:,2)
			p.dt(:,1) p.dt(:,3)
			p.dt(:,2) p.dt(:,3)
		];
		p.dt=asunique(p.dt);
		p.nd=size(p.dt,1);
		p.dl=(	(p.x(p.dt(:,1))-p.x(p.dt(:,2))).^2+...
			(p.y(p.dt(:,1))-p.y(p.dt(:,2))).^2	);
		p.dl=.5*sqrt(p.dl);
		[p.dl,p.dix]=sort(p.dl);
		p.dt=p.dt(p.dix,:);
		p.drng=[min(p.dl) max(p.dl)];
		p.dmod=zeros(size(p.x));
		p.dix=find(p.dl<=p.r,1,'last');
	if	isempty(p.dix)
		p.dix=0;
	end
		return;
%--------------------------------------------------------------------------------
function	m=asunique(m)
% - a poor man's <unique> replacement

	if	isempty(m)
		return;
	end

		ms=size(m,1);
	if	ms == 1
		m=m(:);
	end
		m=sortrows(m);
		iu=[true;any(diff(m,1),2)];
		m=m(iu,:);
	if	ms == 1
		m=m.';
	end
		return;
%--------------------------------------------------------------------------------
function	cp=ascp(u,v)
% - a poor man's <2d cross product> replacement

		cp=u(:,1).*v(:,2)-u(:,2).*v(:,1);
		return;
%--------------------------------------------------------------------------------
function	vdisp(p,txt)
% - display text in verbose mode

	if	p.flg.vflg
		disp(txt);
	end
		return;
%--------------------------------------------------------------------------------
%--------------------------------------------------------------------------------
% ASLIB GRAPHICS FUNCTIONS
%--------------------------------------------------------------------------------
% - graphics utilities
%--------------------------------------------------------------------------------
function	[p,r]=set_graph(p,n,tag,varargin)

		aschk(p,1);
		r=true;
	if	numel(n) <= 0 || all(n(:) <=0)
		r=false;
	elseif	nargin > 3
	if	isnumeric(varargin{1})
		p=clr_graph(p,tag);
		r=false;
	else
		p=asopt(p,1,varargin{:});
	end
	end
		p=set_axis(p);
		return;		
%--------------------------------------------------------------------------------
function	p=clr_graph(p,tag)

		lh=findall(gcf,'tag',tag);
		delete(lh);
		p.h.(tag)={};
		return;
%--------------------------------------------------------------------------------
function	p=set_axis(p)

	if	~strcmp(get(gca,'tag'),p.magic);
		axis equal;
		xrng=[min(p.x) max(p.x)];
		xdif=diff(xrng);
		yrng=[min(p.y) max(p.y)];
		r=min(p.r,p.drng(2)/2);
	if	r < .025*xdif
		r=.025*xdif;
	end
		r=2*r*[-1 1];
		set(gca,'xlim',r+xrng);
		set(gca,'ylim',r+yrng);
		set(gca,'tag',p.magic);
	end
		return;
%--------------------------------------------------------------------------------
function	p=get_colormap(p,mod)

	switch	mod

% - A shapes
	case	1
	if	isempty(p.flg.cmap)
% - create a simple red/blue only colormap
		cmapr=linspace(1,0,p.nshape).';
		cmapg=zeros(p.nshape,1);
		cmapb=linspace(0,1,p.nshape).';
		p.flg.cmap=[cmapr cmapg cmapb];
	elseif	ischar(p.flg.cmap)
		cmap=str2func(p.flg.cmap);
		p.flg.cmap=cmap(p.nshape);
	end
		p.flg.csiz=size(p.flg.cmap,1);
		p.flg.cmix=rem((1:p.nshape)-1,p.flg.csiz)+1;
		colormap(p.flg.cmap(1:min(p.flg.csiz,p.nshape),:));

% - A patches
	case	2
	if	~p.flg.amap
		cn1=max(1,floor(p.npatch/2));
		cnr=[linspace(1,0,cn1).';linspace(1,0,cn1).'];
		cng=[linspace(0,1,cn1).';linspace(1,0,cn1).'];
		cnb=[zeros(1,cn1).';linspace(0,1,cn1).'];
		cmap=[cnr cng cnb];
	if	size(cmap,1) < p.npatch
		cn2=ceil(p.npatch/2);
		cmap=[cmap(1:cn1,:);[1 .8 1];cmap(cn2:end,:)];
	elseif	size(cmap,1) > p.npatch
		cmap=cmap(1:cn1,:);
	end
		p.flg.acmap=cmap;
	else
		p.flg.acmap=p.flg.cmap;
	end

	end
		return;
%--------------------------------------------------------------------------------
% - user visible functions
%--------------------------------------------------------------------------------
function	p=gall(p,varargin)

		aschk(p,1);
% - plot all resulting elements
		p=gdat(p,varargin{:});
		p=gcir(p,varargin{:});
		p=gcon(p,varargin{:});
		p=gseg(p,varargin{:});

		set(gcf,'tag',p.magic);
		drawnow;
		shg;
		return;
%--------------------------------------------------------------------------------
function	p=gdat(p,varargin)

% - plot data

		tag=[p.h.pref 'dat'];
		[p,r]=set_graph(p,p.n,tag,varargin{:});
	if	~r
		return;
	end

		p.h.(tag){1,1}=...
		line(	p.x,p.y,...
			'marker','square',...
			'markersize',4,...
			'markerfacecolor',.8*[1 1 0],...
			'linestyle','none',...
			'color',[0 0 0],...
			'tag',tag).';
		return;
%--------------------------------------------------------------------------------
function	p=gcir(p,varargin)

% - plot A circles

		tag=[p.h.pref 'cir'];
		[p,r]=set_graph(p,~p.flg.ncir*length(p.cen),tag,varargin{:});
	if	~r
		return;
	end

		cz=-1*ones(size(p.xcir));
	for	i=1:size(p.cen,1)
		cx=p.xcir+p.cen(i,1);
		cy=p.ycir+p.cen(i,2);
	if	p.amod(i) == 2 && p.flg.bcir
		col=.50*[1 1 1];
	else
		col=.85*[1 1 1];
	end
		p.h.(tag){i,1}=...
		line(	cx,cy,cz,...
			'color',col,...
			'tag',tag).';
	end
		return;
%--------------------------------------------------------------------------------
function	p=gseg(p,varargin)

% - plot A edges

		tagr=[p.h.pref 'seg'];
		tagp=[p.h.pref 'segp'];
		p    =set_graph(p,p.segp,tagp,varargin{:});
		[p,r]=set_graph(p,p.seg ,tagr,varargin{:});
	if	~r
		return;
	end

	if	p.nshape
		p=get_colormap(p,1);
	for	i=1:p.nshape
		p.h.(tagr){i,1}=...
		line(	p.x(p.ashape{i}).',...
			p.y(p.ashape{i}).',...
			-.75*ones(size(p.x(p.ashape{i}).')),...
			'linewidth',1,...
			'color',p.flg.cmap(p.flg.cmix(i),:),...
			'tag',tagr).';
	end
	else
		p.h.(tagr){1,1}=...
		line(	p.x(p.seg).',...
			p.y(p.seg).',...
			'linewidth',1,...
			'color',[.5 .5 0],...
			'tag',tagr).';
	end
	if	~isempty(p.segp)
		p.h.(tagp){1,1}=...
		line(	p.x(p.segp).',...
			p.y(p.segp).',...
			'linewidth',4,...
			'hittest','off',...
			'color',[1 1 0],...
			'tag',tagp).';
	end
		return;
%--------------------------------------------------------------------------------
function	p=gcon(p,varargin)

% - plot A nodes

		tag=[p.h.pref 'con'];
		[p,r]=set_graph(p,p.nshape,tag,varargin{:});
	if	~r
		return;
	end

		p=get_colormap(p,1);
	for	i=1:p.nshape
		mfc=p.flg.cmap(p.flg.cmix(i),:);
	if	1 || isequal(mfc,[1 1 1]);
		mfc=[0 0 0];
	end
		p.h.(tag){i,1}=...
		line(...
			p.x(p.ashape{i,:}),...
			p.y(p.ashape{i,:}),...
			ones(size(p.x(p.ashape{i,:}))),...
			'marker','square',...
			'markersize',4,...
			'markerfacecolor',p.flg.cmap(p.flg.cmix(i),:),...
			'linestyle','none',...
			'color',mfc,...
			'tag',tag).';
	end
		cbar=p.h.([p.h.pref 'bar']){1};
	if	ishandle(cbar)
		delete(cbar);
	end
		cbar=colorbar('v6','horizontal');
		set(cbar,...
			'xtick',1.5:p.n+.5,...
			'xticklabel',1:p.n,...
			'ticklength',[0 0],...
			'tag',tag);
		p.h.([p.h.pref 'bar']){1}=cbar;
		return;
%--------------------------------------------------------------------------------
function	p=gpat(p,varargin)

% - plot A patches

		tag=[p.h.pref 'pat'];
		[p,r]=set_graph(p,p.npatch,tag,varargin{:});
	if	~r
		return;
	end

		p=p.f.gseg(p);
		p=p.f.gcon(p);
		th=findall(gca);
		tl=get(th,'tag');
		ix=strncmp(p.h.pref,tl,3);
		set(th(ix),'hittest','off');
		cbar=p.h.([p.h.pref 'bar']){1};
	if	ishandle(cbar)
		delete(cbar);
	end

		ix=p.amod==2;
		line(...
			p.x(p.seg(ix,:)).',...
			p.y(p.seg(ix,:)).',...
			-.5*ones(size(p.x(p.seg(ix,:)))).',...
			'linewidth',2,...
			'hittest','off',...
			'color',[0 0 0]);

		oax=gca;
		cbar=colorbar('v6','horizontal');
		p.h.([p.h.pref 'bar']){1}=cbar;
		axes(oax);

		phh=[];
		php=[];
		[nr,nc]=size(p.apatch);
	if	p.npatch
		p=get_colormap(p,2);
		ixp=p.xpatch;
		bmap=zeros(p.npatch,3);
		txt=cell(p.npatch,1);
		cix=0;
		zv=linspace(-1.5,-1,p.npatch);
	for	i=1:nr
	for	j=1:nc
		dix=p.apatch{i,j};
	if	~isempty(dix)
		cix=cix+1;
	if	~p.flg.amap
		col=p.flg.acmap(cix,:);
	else
		col=p.flg.cmap(ixp(i),:);
	end	
		bmap(cix,:)=col;
		vx=p.x(dix);
		vy=p.y(dix);
		vz=zv(cix)*ones(size(vx));
		ph=patch(...
			vx,vy,vz,col,...
			'edgecolor','none',...
			'tag',sprintf('%-1d',i),...
			'userdata',{0,col,0,i,cix});
		php=[php;ph];				%#ok
		set(ph,...
			'buttondownfcn',...
			{@gpat_cb,p,oax,ph,2,php});
		pause(.01);
		txt{cix}=sprintf('%-1d\n%-1d\n%-1d',i,j,length(dix)-1);
	end
	end
		k=p.ashape{ixp(i)};
		kx=convhull(p.x(k),p.y(k));
		k=k(kx);
		phh=[phh;patch(...
			p.x(k),p.y(k),-2*ones(size(k)),[1 .95 .95],...
			'edgecolor',[1 .75 .75],...
			'userdata',{0,i,0,i,[1 .95 .95]},...
			'tag',tag)];			%#ok
	end

		colormap(bmap);
		cbar=colorbar('v6','horizontal');
		p.h.([p.h.pref 'bar']){1}=cbar;
		xtick=((1:p.npatch)-.5)./p.npatch;
		set(cbar,...
			'xtick',xtick,...
			'xticklabel',[],...
			'ytick',[-.5 1.5],...
			'yticklabel',{'patch';'shape'},...
			'ticklength',[0 0],...
			'tag',tag);
		axes(cbar);
		text(xtick,-2.5*ones(size(xtick)),txt,...
			'horizontalalignment','center',...
			'fontsize',7);

		ylim=get(cbar,'ylim');
		ybot=ylim(1)+range(ylim)/2;
		ytop=ylim(2);
		lx=linspace(0,1,p.npatch+1);
		nw=0;
		xo=0;
	for	i=1:nr
		col=p.flg.cmap(p.flg.cmix(ixp(i)),:);
		nw=nw+find(p.lpatch(i,:),1,'last');
		x=lx(nw+1);
		phc=patch(...
			[xo x x xo],[ybot ybot ytop ytop],col,...
			'edgecolor','none',...
			'userdata',{0,i,0,i,col});
		set(phc,...				% keep this logic!
			'buttondownfcn',...
			{@gpat_cb,p,oax,phc,1});
		set(phh(i),...
			'buttondownfcn',...
			{@gpat_cb,p,oax,phc,1});
		xo=x;
	end
		set(cbar,...
			'buttondownfcn',...
			{@gpat_cb,p,oax,php,0})
		lh=line([lx;lx],ylim);
		lh=[lh;line([0 1],[.5 .5])];
		set(lh,...
			'hittest','off',...
			'color',[0 0 0]);
		axes(oax);
	end
		title(cbar,p.pmod);
		return;
%--------------------------------------------------------------------------------
function	gpat_cb(h,e,varargin)			%#ok

% - callback routine for GPAT

		p=varargin{1};
		cn=p.npatch;
		nax=p.h.([p.h.pref 'bar']){1};
		oax=varargin{2};
		phv=varargin{3};
		mod=varargin{4};

	if	~ishandle(nax) || ~ishandle(oax)
		return;
	end

% - user selected
%   shape on axis: mimick option <patch on colorbar>
	if	mod == 2
		ud=get(phv,'userdata');
		ap=ud{5};
		phv=varargin{5};
	else
		ap=get(nax,'currentpoint');
		ap=fix(ap(1,1)*cn)+1;
	end

%   shape on colorbar
	if	mod == 1
		ud=get(phv,'userdata');
		ph=findall(oax,'tag',sprintf('%-1d',ud{2}));
	if	ud{1} == 0
		set(ph,...
			'facecolor',p.flg.pscol);
		set(phv,...
			'facecolor',p.flg.pscol,...
			'userdata',{1,ud{2},ph,ud{4},ud{5}});
	else
		set(phv,...
			'facecolor',ud{5},...
			'userdata',{0,ud{2},ph,ud{4},ud{5}});
	for	i=1:size(ph,1)
		ud=get(ph(i),'userdata');
		set(ph(i),...
			'facecolor',ud{2});
	end
	end

%   patch on colorbar
	else
		phv=phv(ap);
		ud=get(phv,'userdata');
	if	ud{1} == 0
		xt=get(nax,'xtick');
		yt=get(nax,'ytick');
		th=text(...
			xt(ap),yt(2),'+',...
			'parent',nax,...
			'fontsize',6,...
			'horizontalalignment','center',...
			'verticalalignment','top',...
			'backgroundcolor',[1 1 1],...
			'hittest','off',...
			'color',[0 0 0]);
		axes(oax);
		x=get(phv,'xdata');
		y=get(phv,'ydata');
		lh=line(...
			[min(x) max(x) max(x) min(x) min(x)],...
			[min(y) min(y) max(y) max(y) min(y)],...
			'linewidth',3,...
			'hittest','off',...
			'color',[0 0 1]);
		set(phv,...
			'facecolor',p.flg.pscol,...
			'userdata',{1,ud{2},[lh,th],ud{4},ud{5}});
	else
		delete(ud{3});
		set(phv,...
			'facecolor',ud{2},...
			'userdata',{0,ud{2},0,ud{4},ud{5}});
	end
	end
		axes(oax);
		return;
%--------------------------------------------------------------------------------
