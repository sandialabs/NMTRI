function X = generate_sphere_sphere ( n, r )
% function X = generate_sphere_torus ( n, r );
% This function generates random data for a sphere intersecting
% another sphere.
%
% INPUTS: n -- number of points on sphere & torus (each)
%         r -- minimum distance to use for uniform sampling
%
% OUTPUTS: X -- sphere^2 in 3d (x,y,z) coordinates
%
% S. Martin
% 3/24/2009

% set random seed for repeatable results
s = RandStream.create('mt19937ar','seed',0);

% first generate sphere

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z direction angle
rho = rand(s,1,n)*pi;

rad_sphere = 1;

% find x,y,z using spherical transforms
x = rad_sphere*cos(theta).*sin(rho);
y = rad_sphere*sin(theta).*sin(rho);
z = rad_sphere*cos(rho);
X_sphere = [x;y;z];

% generate second sphere

displacement = sqrt(2);  % displacement of sphere relative to origin

% theta describes equatorial angle in xy plane
theta = rand(s,1,n)*2*pi;
% rho desrbes z direction angle
rho = rand(s,1,n)*pi;

rad_sphere = 1;

% find x,y,z using spherical transforms
x = rad_sphere*cos(theta).*sin(rho) + displacement;
y = rad_sphere*sin(theta).*sin(rho);
z = rad_sphere*cos(rho);
X_sphere_2 = [x;y;z];

% sample uniformly from set
X = [X_sphere, X_sphere_2];
inds = sample_cluster ( X, r, 2*n );
X = X(:,inds);